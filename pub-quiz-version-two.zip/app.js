const geographyQuestions = [
  {
    QuestionNumber: 1,
    Category: "Geography",
    Question: "What is the capital city of Peru?",
    OptionA: "La Paz",
    OptionB: "Bogota",
    OptionC: "Lima",
    OptionD: "Cancun",
    CorrectAnswer: "C",
    CorrectAnswerText: "Correct! The Peruvian capital is Lima",
    WrongAnswerText: "Wrong! The Peruvian capital is Lima"
  },
  {
    QuestionNumber: 2,
    Category: "Geography",
    Question:
      "In which Middle Eastern country would you find the ancient ruins of Petra?",
    OptionA: "Iraq",
    OptionB: "Iran",
    OptionC: "Lebanon",
    OptionD: "Jordan",
    CorrectAnswer: "D",
    CorrectAnswerText:
      "Correct! Petra is a Wonder of the World and can be found in Jordan",
    WrongAnswerText:
      "Wrong! Petra is a Wonder of the World and can be found in Jordan"
  },
  {
    QuestionNumber: 3,
    Category: "Geography",
    Question: "What is the currency of Sweden?",
    OptionA: "Krona",
    OptionB: "Euro",
    OptionC: "Ruble",
    OptionD: "Yen",
    CorrectAnswer: "A",
    CorrectAnswerText:
      "Correct! The Swedish Krona is the official currency of Sweden",
    WrongAnswerText:
      "Wrong! The Swedish Krona is the official currency of Sweden"
  },
  {
    QuestionNumber: 4,
    Category: "Geography",
    Question: "Mount Vesuvius overlooks which present-day Italian city?",
    OptionA: "Rome",
    OptionB: "Naples",
    OptionC: "Venice",
    OptionD: "Milan",
    CorrectAnswer: "B",
    CorrectAnswerText:
      "Correct! Mount Vesuvius is an active volcano that overlooks Naples",
    WrongAnswerText:
      "Wrong! Mount Vesuvius is an active volcano that overlooks Naples"
  },
  {
    QuestionNumber: 5,
    Category: "Geography",
    Question:
      "Constantinople and Byzantium are former names of which major city?",
    OptionA: "Athens",
    OptionB: "Istanbul",
    OptionC: "Tehran",
    OptionD: "Zagreb",
    CorrectAnswer: "B",
    CorrectAnswerText:
      "Correct! The Byzantine Empires capital city was Constantinople, which today is Istanbul",
    WrongAnswerText:
      "Wrong! The Byzantine Empires capital city was Constantinople, which today is Istanbul"
  },
  {
    QuestionNumber: 6,
    Category: "Geography",
    Question: "What is the largest desert in the world?",
    OptionA: "Sahara",
    OptionB: "Gobi",
    OptionC: "Atacama",
    OptionD: "Antarctica",
    CorrectAnswer: "D",
    CorrectAnswerText:
      "Correct! At 5.5 million square miles, Antarctica is by far the worlds largest desert",
    WrongAnswerText:
      "Wrong! At 5.5 million square miles, Antarctica is by far the worlds largest desert"
  },
  {
    QuestionNumber: 7,
    Category: "Geography",
    Question:
      "What is the name of the microstate located between Spain and France?",
    OptionA: "Andorra",
    OptionB: "Monaco",
    OptionC: "Montenegro",
    OptionD: "Almaty",
    CorrectAnswer: "A",
    CorrectAnswerText: "Correct! Its Andorra",
    WrongAnswerText: "Wrong! Its Andorra"
  },
  {
    QuestionNumber: 8,
    Category: "Geography",
    Question: "To the nearest billion, how large is the worlds population?",
    OptionA: "77 Billion",
    OptionB: "50 Billion",
    OptionC: "22 Billion",
    OptionD: "8 Billion",
    CorrectAnswer: "D",
    CorrectAnswerText:
      "Correct! The more accurate figure is roughly 7.8 billion",
    WrongAnswerText: "Wrong! The more accurate figure is roughly 7.8 billion"
  },
  {
    QuestionNumber: 9,
    Category: "Geography",
    Question: "In which UK city would you find the river Clyde?",
    OptionA: "Manchester",
    OptionB: "Belfast",
    OptionC: "Glasgow",
    OptionD: "Newcastle",
    CorrectAnswer: "C",
    CorrectAnswerText:
      "Correct! The river Clyde runs through the major city of Glasgow",
    WrongAnswerText:
      "Wrong! The river Clyde runs through the major city of Glasgow"
  },
  {
    QuestionNumber: 10,
    Category: "Geography",
    Question: "How many states are there in Australia?",
    OptionA: 6,
    OptionB: 8,
    OptionC: 10,
    OptionD: 12,
    CorrectAnswer: "A",
    CorrectAnswerText:
      "Correct! Six – New South Wales, Victoria, Queensland, Western Australia, Tasmania, South Australia",
    WrongAnswerText:
      "Wrong! Six – New South Wales, Victoria, Queensland, Western Australia, Tasmania, South Australia"
  }
];

const scienceQuestions = [
  {
    QuestionNumber: 1,
    Category: "Science",
    Question: "How many bones are in the human body?",
    OptionA: 188,
    OptionB: 209,
    OptionC: 272,
    OptionD: 301,
    CorrectAnswer: "B",
    CorrectAnswerText: "Correct! There are 209 bones in the human body",
    WrongAnswerText: "Wrong! There are 209 bones in the human body"
  },
  {
    QuestionNumber: 2,
    Category: "Science",
    Question:
      "The concept of gravity was discovered by which famous physicist?",
    OptionA: "Newton",
    OptionB: "Einstein",
    OptionC: "Curie",
    OptionD: "Galilei",
    CorrectAnswer: "A",
    CorrectAnswerText:
      "Correct! Isaac Newton formulated gravitational theory in 1665",
    WrongAnswerText:
      "Wrong! Isaac Newton formulated gravitational theory in 1665"
  },
  {
    QuestionNumber: 3,
    Category: "Science",
    Question:
      "Roughly how long does it take for the suns light to reach Earth?",
    OptionA: "8 seconds",
    OptionB: "8 minutes",
    OptionC: "8 hours",
    OptionD: "8 days",
    CorrectAnswer: "B",
    CorrectAnswerText: "Correct! It takes roughly 8 minutes",
    WrongAnswerText: "Wrong! It takes roughly 8 minutes"
  },
  {
    QuestionNumber: 4,
    Category: "Science",
    Question: "What is the study of mushrooms called?",
    OptionA: "Botany",
    OptionB: "Biology",
    OptionC: "Ornithology",
    OptionD: "Mycology",
    CorrectAnswer: "D",
    CorrectAnswerText: "Correct! Mycology the scientific study of fungi",
    WrongAnswerText: "Wrong! Mycology the scientific study of fungi"
  },
  {
    QuestionNumber: 5,
    Category: "Science",
    Question: "What is the hardest natural substance on Earth?",
    OptionA: "Diamond",
    OptionB: "Iron",
    OptionC: "Gold",
    OptionD: "Silver",
    CorrectAnswer: "A",
    CorrectAnswerText:
      "Correct! Diamond is the hardest natural substance on Earth",
    WrongAnswerText: "Wrong! Diamond is the hardest natural substance on Earth"
  },
  {
    QuestionNumber: 6,
    Category: "Science",
    Question: "Which is the main gas that makes up the Earths atmosphere?",
    OptionA: "Oxygen",
    OptionB: "Butane",
    OptionC: "Nitrogen",
    OptionD: "Helium",
    CorrectAnswer: "C",
    CorrectAnswerText:
      "Correct! Earths atmosphere is made up of approximately 78% nitrogen and 21% oxygen",
    WrongAnswerText:
      "Wrong! Earths atmosphere is made up of approximately 78% nitrogen and 21% oxygen"
  },
  {
    QuestionNumber: 7,
    Category: "Science",
    Question: "What modern-day country was Marie Curie born in?",
    OptionA: "England",
    OptionB: "Poland",
    OptionC: "Germany",
    OptionD: "France",
    CorrectAnswer: "B",
    CorrectAnswerText:
      "Correct! Marie Curie was born in Warsaw, Poland in 1867",
    WrongAnswerText: "Wrong! Marie Curie was born in Warsaw, Poland in 1867"
  },
  {
    QuestionNumber: 8,
    Category: "Science",
    Question: "What is the biggest planet in our solar system?",
    OptionA: "Mars",
    OptionB: "Jupiter",
    OptionC: "Saturn",
    OptionD: "Mercury",
    CorrectAnswer: "B",
    CorrectAnswerText:
      "Correct! Jupiter is the largest planet at 61.42 billion km²",
    WrongAnswerText: "Wrong! Jupiter is the largest planet at 61.42 billion km²"
  },
  {
    QuestionNumber: 9,
    Category: "Science",
    Question: "At what temperature are Celsius and Fahrenheit equal?",
    OptionA: 0,
    OptionB: -10,
    OptionC: -25,
    OptionD: -40,
    CorrectAnswer: "D",
    CorrectAnswerText: "Correct! Celsius and Fahrenheit are equal at -40",
    WrongAnswerText: "Wrong! Celsius and Fahrenheit are equal at -40"
  },
  {
    QuestionNumber: 10,
    Category: "Science",
    Question: "How many teeth does an adult human have?",
    OptionA: 32,
    OptionB: 38,
    OptionC: 40,
    OptionD: 42,
    CorrectAnswer: "A",
    CorrectAnswerText: "Correct! The average adult human has 32 teeth",
    WrongAnswerText: "Wrong! The average adult human has 32 teeth"
  }
];

const historyQuestions = [
  {
    QuestionNumber: 1,
    Category: "History",
    Question: "In what year was the Magna Carta signed?",
    OptionA: 1066,
    OptionB: 1108,
    OptionC: 1201,
    OptionD: 1215,
    CorrectAnswer: "D",
    CorrectAnswerText:
      "Correct! The Magna Carta was signed by King John on June 15th 1215",
    WrongAnswerText:
      "Wrong! The Magna Carta was signed by King John on June 15th 1215"
  },
  {
    QuestionNumber: 2,
    Category: "History",
    Question: "Who discovered penicillin?",
    OptionA: "Tom Edison",
    OptionB: "Marie Curie",
    OptionC: "Alex Fleming",
    OptionD: "James Cooke",
    CorrectAnswer: "C",
    CorrectAnswerText:
      "Correct!  Dr Alexander Fleming discovered Penacillin by accident in 1928",
    WrongAnswerText:
      "Wrong! Dr Alexander Fleming discovered Penacillin by accident in 1928"
  },
  {
    QuestionNumber: 3,
    Category: "History",
    Question: "What year did the Challenger Space Shuttle disaster take place?",
    OptionA: "1979",
    OptionB: "1986",
    OptionC: "1990",
    OptionD: "1992",
    CorrectAnswer: "B",
    CorrectAnswerText:
      "Correct! The Challenger disaster was a fatal accident that occurred on January 28 1986",
    WrongAnswerText:
      "Wrong! Correct! The Challenger disaster was a fatal accident that occurred on January 28 1986"
  },
  {
    QuestionNumber: 4,
    Category: "History",
    Question:
      "Which 13th Century Scottish knight did Mel Gibson portray in Braveheart?",
    OptionA: "William Wallace",
    OptionB: "Andrew Moray",
    OptionC: "Robb Stark",
    OptionD: "James Douglas",
    CorrectAnswer: "A",
    CorrectAnswerText:
      "Correct! Mel Gibson played Sir William Wallace in the 1995 film Braveheart",
    WrongAnswerText:
      "Wrong! Mel Gibson played Sir William Wallace in the 1995 film Braveheart"
  },
  {
    QuestionNumber: 5,
    Category: "History",
    Question: "Which part of Berlin was enclosed by the wall?",
    OptionA: "The North",
    OptionB: "The South",
    OptionC: "The East",
    OptionD: "The West",
    CorrectAnswer: "D",
    CorrectAnswerText:
      "Correct! The wall completely encircled all of West Berlin",
    WrongAnswerText: "Wrong! The wall completely encircled all of West Berlin"
  },
  {
    QuestionNumber: 6,
    Category: "History",
    Question: "Who was the first human to journey into space?",
    OptionA: "Neil Armstrong",
    OptionB: "Buzz Aldrin",
    OptionC: "Yuri Gagarin",
    OptionD: "Tim Peake",
    CorrectAnswer: "C",
    CorrectAnswerText:
      "Correct! Soviet cosmonaut Yuri Gagarin became the first human to reach outer space in April 1961",
    WrongAnswerText:
      "Wrong! Soviet cosmonaut Yuri Gagarin became the first human to reach outer space in April 1961"
  },
  {
    QuestionNumber: 7,
    Category: "History",
    Question:
      "What was the name given to the coding machine used by the Germans in World War II?",
    OptionA: "Ex-Machina",
    OptionB: "Enigma",
    OptionC: "Europa",
    OptionD: "Euphoria",
    CorrectAnswer: "B",
    CorrectAnswerText:
      "Correct! Mathematician Alan Turing cracked the Enigma Code in 1939",
    WrongAnswerText:
      "Wrong! Mathematician Alan Turing cracked the Enigma Code in 1939"
  },
  {
    QuestionNumber: 8,
    Category: "History",
    Question: "In which century was The Black Death?",
    OptionA: "14th",
    OptionB: "15th",
    OptionC: "16th",
    OptionD: "17th",
    CorrectAnswer: "A",
    CorrectAnswerText:
      "Correct! The Bubonic Plague (AKA The Black Death) decimated Europe from 1346 – 1352",
    WrongAnswerText:
      "Wrong! The Bubonic Plague (AKA The Black Death) decimated Europe from 1346 – 1352"
  },
  {
    QuestionNumber: 9,
    Category: "History",
    Question: "April 1889 saw the birth of which future dictator?",
    OptionA: "Adolf Hitler",
    OptionB: "Joseph Stalin",
    OptionC: "Pol Pot",
    OptionD: "Mao Zedong",
    CorrectAnswer: "A",
    CorrectAnswerText: "Correct! April 1889 saw the birth of Adolf Hitler",
    WrongAnswerText: "Wrong! April 1889 saw the birth of Adolf Hitler"
  },
  {
    QuestionNumber: 10,
    Category: "History",
    Question: "Which animal was considered sacred in ancient Egypt?",
    OptionA: "Cow",
    OptionB: "Snake",
    OptionC: "Cat",
    OptionD: "Horse",
    CorrectAnswer: "C",
    CorrectAnswerText:
      "Correct! Ancient Egyptians believed cats to be sacred, and they also kept them as pets",
    WrongAnswerText:
      "Wrong! Ancient Egyptians believed cats to be sacred, and they also kept them as pets"
  }
];

const movieQuestions = [
  {
    QuestionNumber: 1,
    Category: "Movies",
    Question: "Who directed Titanic, Avatar and The Terminator?",
    OptionA: "George Lucas",
    OptionB: "James Cameron",
    OptionC: "Steven Spielberg",
    OptionD: "Martin Scorsese",
    CorrectAnswer: "B",
    CorrectAnswerText: "Correct! It was James Cameron",
    WrongAnswerText: "Wrong! It was James Cameron"
  },
  {
    QuestionNumber: 2,
    Category: "Movies",
    Question: "For which film did Sandra Bullock win her Oscar?",
    OptionA: "The Blind Side",
    OptionB: "Speed",
    OptionC: "Gravity",
    OptionD: "Bird Box",
    CorrectAnswer: "A",
    CorrectAnswerText:
      "Correct! For her role in The Blind Side, Sandra Bullock won the Academy Award for Best Actress",
    WrongAnswerText:
      "Wrong! For her role in The Blind Side, Sandra Bullock won the Academy Award for Best Actress"
  },
  {
    QuestionNumber: 3,
    Category: "Movies",
    Question:
      "Which movie features an iconic dance scene between Uma Thurman and John Travolta?",
    OptionA: "Reservoir Dogs",
    OptionB: "Kill Bill",
    OptionC: "Jackie Brown",
    OptionD: "Pulp Fiction",
    CorrectAnswer: "D",
    CorrectAnswerText:
      "Correct! The scene from Pulp Fiction is considered one of the most memorable dance scenes in film history",
    WrongAnswerText:
      "Wrong! It is from Pulp Fiction and is considered one of the most memorable dance scenes in film history"
  },
  {
    QuestionNumber: 4,
    Category: "Movies",
    Question:
      "Who played the lead role in the 2001 film Lara Croft: Tomb Raider?",
    OptionA: "Charlize Theron",
    OptionB: "Halle Berry",
    OptionC: "Angelina Jolie",
    OptionD: "Kate Mara",
    CorrectAnswer: "C",
    CorrectAnswerText:
      "Correct! The lead role in Lara Croft: Tomb Raider was played by Angelina Jolie",
    WrongAnswerText:
      "Wrong! The lead role in Lara Croft: Tomb Raider was played by Angelina Jolie"
  },
  {
    QuestionNumber: 5,
    Category: "Movies",
    Question: "What does Tom Hanks compare life to in Forest Gump?",
    OptionA: "Chocolates",
    OptionB: "Wine",
    OptionC: "Diamonds",
    OptionD: "Flowers",
    CorrectAnswer: "A",
    CorrectAnswerText:
      "Correct! In Forest Gump, Tom Hanks iconically compared life to a box of chocolates",
    WrongAnswerText:
      "Wrong! In Forest Gump, Tom Hanks iconically compared life to a box of chocolates"
  },
  {
    QuestionNumber: 6,
    Category: "Movies",
    Question:
      "Cool Runnings is the story of which country entering a bobsleigh team into the Winter Olympics?",
    OptionA: "Barbados",
    OptionB: "Jamaica",
    OptionC: "Seychelles",
    OptionD: "The Maldives",
    CorrectAnswer: "B",
    CorrectAnswerText:
      "Correct! The film is loosely based on the true story of the Jamaican bobsleigh team during the 1988 Winter Olympics.",
    WrongAnswerText:
      "Wrong! The film is loosely based on the true story of the Jamaican bobsleigh team during the 1988 Winter Olympics."
  },
  {
    QuestionNumber: 7,
    Category: "Movies",
    Question:
      "Kirk Douglas played the title role in which 1960 film about Roman slaves?",
    OptionA: "Gladiator",
    OptionB: "Spartacus",
    OptionC: "Ben Hur",
    OptionD: "Troy",
    CorrectAnswer: "B",
    CorrectAnswerText:
      "Correct! Kirk Douglas played a Roman slave in Spartacus. The movie won 4 Oscars",
    WrongAnswerText:
      "Wrong! Kirk Douglas played a Roman slave in Spartacus. The movie won 4 Oscars"
  },
  {
    QuestionNumber: 8,
    Category: "Movies",
    Question:
      "In the Star Wars series of films what is the name of Han Solo’s Wookie co-pilot?",
    OptionA: "C3PO",
    OptionB: "R2-D2",
    OptionC: "Chewbacca",
    OptionD: "Jar Jar Binks",
    CorrectAnswer: "C",
    CorrectAnswerText:
      "Correct. It was Chewbacca. The character was inspired by George Lucas’s large dog.",
    WrongAnswerText:
      "Wrong! It was Chewbacca. The character was inspired by George Lucas’s large dog."
  },
  {
    QuestionNumber: 9,
    Category: "Movies",
    Question:
      "Which actor played the President in the 1997 film ‘Air Force One’?",
    OptionA: "Kevin Spacey",
    OptionB: "Liam Neeson",
    OptionC: "Tommy Lee Jones",
    OptionD: "Harrison Ford",
    CorrectAnswer: "D",
    CorrectAnswerText:
      "Correct! Harrison Ford played fictional heroic US President James Marshall",
    WrongAnswerText:
      "Wrong! Harrison Ford played fictional heroic US President James Marshall"
  },
  {
    QuestionNumber: 10,
    Category: "Movies",
    Question: "Which actor plays James Bond in Skyfall and Casino Royale?",
    OptionA: "Daniel Craig",
    OptionB: "Pierse Brosnan",
    OptionC: "Sean Connery",
    OptionD: "Roger Moore",
    CorrectAnswer: "A",
    CorrectAnswerText:
      "Correct! The roles were played by Daniel Craig, who was the longest serving Bond with 15 years and 5 films",
    WrongAnswerText:
      "Wrong! The roles were played by Daniel Craig, who was the longest serving Bond with 15 years and 5 films"
  }
];

const generalQuestions = [
  {
    QuestionNumber: 1,
    Category: "General Knolwege",
    Question: "Name the Coffee shop in US sitcom Friends",
    OptionA: "Central Perk",
    OptionB: "Bronx Coffee",
    OptionC: "Starbucks",
    OptionD: "NYC Diner",
    CorrectAnswer: "A",
    CorrectAnswerText:
      "Correct! It was Central Perk features frequently throughout the series",
    WrongAnswerText:
      "Wrong! It was Central Perk. The NY cafe features frequently throughout the series"
  },
  {
    QuestionNumber: 2,
    Category: "General Knowledge",
    Question:
      "Street artist Banksy is originally associated with which British city?",
    OptionA: "Brighton",
    OptionB: "Bristol",
    OptionC: "Oxford",
    OptionD: "Reading",
    CorrectAnswer: "B",
    CorrectAnswerText:
      "Correct! Banksy is an anonymous graffiti artist who is said to have been born in Bristol",
    WrongAnswerText:
      "Wrong! Banksy is an anonymous graffiti artist who is said to have been born in Bristol"
  },
  {
    QuestionNumber: 3,
    Category: "General Knowlege",
    Question: "How many times has England won the men's football World Cup?",
    OptionA: 1,
    OptionB: 2,
    OptionC: 3,
    OptionD: 4,
    CorrectAnswer: "A",
    CorrectAnswerText:
      "Correct! To date, England have won the competion only once in 1966",
    WrongAnswerText:
      "Wrong! To date, England have won the competion only once in 1966"
  },
  {
    QuestionNumber: 4,
    Category: "General Knowlege",
    Question:
      "In which part of your body would you find the cruciate ligament?",
    OptionA: "Spine",
    OptionB: "Shouler",
    OptionC: "Knee",
    OptionD: "Elbow",
    CorrectAnswer: "C",
    CorrectAnswerText:
      "Correct! The anterior cruciate ligament is one of the key ligaments that help stabilize the knee joint",
    WrongAnswerText:
      "Wrong! The anterior cruciate ligament is one of the key ligaments that help stabilize the knee joint"
  },
  {
    QuestionNumber: 5,
    Category: "General Knowlege",
    Question: "How many of Henry VIII wives were called Catherine?",
    OptionA: 1,
    OptionB: 2,
    OptionC: 3,
    OptionD: 4,
    CorrectAnswer: "C",
    CorrectAnswerText:
      "Correct! Catherine of Aragon, Catherine Howard, and Catherine Parr (in that order)",
    WrongAnswerText:
      "Wrong! Three - Catherine of Aragon, Catherine Howard, and Catherine Parr (in that order)"
  },
  {
    QuestionNumber: 6,
    Category: "General Knowlege",
    Question: "From what grain is the Japanese spirit Sake made?",
    OptionA: "Oats",
    OptionB: "Corn",
    OptionC: "Barley",
    OptionD: "Rice",
    CorrectAnswer: "D",
    CorrectAnswerText:
      "Correct! Sake is made by fermenting rice that has been polished to remove the bran",
    WrongAnswerText:
      "Wrong! Sake is made by fermenting rice that has been polished to remove the bran"
  },
  {
    QuestionNumber: 7,
    Category: "General Knowlege",
    Question:
      "Which legendary surrealist artist is famous for painting melting clocks?",
    OptionA: "Salvador Dali",
    OptionB: "Pablo Picasso",
    OptionC: "Roy Lichtenstein",
    OptionD: "René Magritte",
    CorrectAnswer: "A",
    CorrectAnswerText:
      "Correct! The melting clocks represent the omnipresence of time and its mastery over human beings",
    WrongAnswerText:
      "Wrong! It was Dali. The clocks represent the omnipresence of time and its mastery over humans"
  },
  {
    QuestionNumber: 8,
    Category: "General Knowlege",
    Question:
      "Which popular video game franchise has released games with the subtitles World At War and Black Ops?",
    OptionA: "Halo",
    OptionB: "Call of Duty",
    OptionC: "Fortnite",
    OptionD: "GTA",
    CorrectAnswer: "B",
    CorrectAnswerText:
      "Correct. Call of Duty is a popular franchise with the subtitles World At War and Black Ops",
    WrongAnswerText:
      "Wrong! Call of Duty is a popular franchise with the subtitles World At War and Black Ops"
  },
  {
    QuestionNumber: 9,
    Category: "General Knowlege",
    Question: "In what US State is the city Nashville?",
    OptionA: "Tennessee",
    OptionB: "Colorado",
    OptionC: "Mississippi",
    OptionD: "Montana",
    CorrectAnswer: "A",
    CorrectAnswerText:
      "Correct! Nashville is the capital of the U.S. state of Tennessee",
    WrongAnswerText:
      "Wrong! Nashville is the capital of the U.S. state of Tennessee"
  },
  {
    QuestionNumber: 10,
    Category: "General Knowlege",
    Question: "Which rock band was founded by Trent Reznor in 1988?",
    OptionA: "Slipknot",
    OptionB: "Iron Maiden",
    OptionC: "Metallica",
    OptionD: "Nine Inch Nails",
    CorrectAnswer: "D",
    CorrectAnswerText: "Correct! Trent Reznor founded Nine Inch Nails in 1988",
    WrongAnswerText: "Wrong! Trent Reznor founded Nine Inch Nails in 1988"
  }
];
//GAMEPLAY VARIABLES

const startBtn = document.getElementById("start-btn");
const box1 = document.getElementById("box1");
const nextBtn = document.getElementById("next-btn");
const gameText = document.getElementById("game-text");
const optionAbutton = document.getElementById("optionA");
const optionBbutton = document.getElementById("optionB");
const optionCbutton = document.getElementById("optionC");
const optionDbutton = document.getElementById("optionD");
const scoreBox = document.getElementById("score-box");
const category = document.getElementById("category");
const questionNum = document.getElementById("question-number");
let score = 0;

//GAMEPLAY FUNCTIONS

//To disable the buttons
function disableButtons() {
  optionAbutton.disabled = true;
  optionBbutton.disabled = true;
  optionCbutton.disabled = true;
  optionDbutton.disabled = true;
}

//To activate buttons
function activateButtons() {
  optionAbutton.disabled = false;
  optionBbutton.disabled = false;
  optionCbutton.disabled = false;
  optionDbutton.disabled = false;
}

//For a correct answer
function correctAnswerFunc() {
  box1.style.backgroundColor = "#34eb67";
  nextBtn.style.visibility = "visible";
  score++;
  scoreBox.innerHTML = `<h3>Score: ${score}</h3>`;
  disableButtons();
}

//For a wrong answer
function wrongAnswerFunc() {
  box1.style.backgroundColor = "#eb5234";
  nextBtn.style.visibility = "visible";
  scoreBox.innerHTML = `<h3>Score: ${score}</h3>`;
  disableButtons();
}

//to return to default settings
function defaultSetting() {
  box1.style.backgroundColor = "#faf0e6";
  activateButtons();
  nextBtn.style.visibility = "hidden";
}

//To Launch the game

function launchGame() {
  startBtn.removeEventListener("click", geographyQuestionOne);
  box1.style.visibility = "visible";
  scoreBox.style.visibility = "visible";
  scoreBox.innerHTML = `<h3>Score: ${score}</h3>`;
  category.innerHTML = `<h5>Geography</h5>`;
  questionNum.innerHTML = `<h5>Question 1</h5>`;
  startBtn.innerText = "RESET";
  gameText.innerHTML = `<h3>${geoQuesOne}</h3>`;
}

//To add event listeners

function addListeners(e, func1, func2, func3, func4) {
  optionAbutton.addEventListener(e, func1);
  optionBbutton.addEventListener(e, func2);
  optionCbutton.addEventListener(e, func3);
  optionDbutton.addEventListener(e, func4);
}

// To remove event listeners

function removeListeners(e, func1, func2, func3, func4, func5) {
  optionAbutton.removeEventListener(e, func1);
  optionBbutton.removeEventListener(e, func2);
  optionCbutton.removeEventListener(e, func3);
  optionDbutton.removeEventListener(e, func4);
  nextBtn.removeEventListener(e, func5);
}

//To add content to the buttons

function buttonContent(func1, func2, func3, func4) {
  optionAbutton.innerText = func1;
  optionBbutton.innerText = func2;
  optionCbutton.innerText = func3;
  optionDbutton.innerText = func4;
}

//To reset the game
function resetGame() {
  location.reload();
}

//To end the game

function endGame() {
  optionAbutton.style.visibility = "hidden";
  optionBbutton.style.visibility = "hidden";
  optionCbutton.style.visibility = "hidden";
  optionDbutton.style.visibility = "hidden";
  nextBtn.style.visibility = "hidden";
  questionNum.style.visibility = "hidden";
  category.style.visibility = "hidden";
  scoreBox.style.visibility = "hidden";
  box1.style.backgroundColor = "#faf0e6";
  gameText.innerHTML = `<h3>Game Over... You Scored ${score} Points!</h3>`;
}

// SHUFFLED ARRAY FUNCTIONS

//Geography Array
function shuffleGeographyArray(array) {
  array.sort(() => Math.random() - 0.5);
}
var geographyArr = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
shuffleGeographyArray(geographyArr);

//Science Array
function shuffleScienceArray(array) {
  array.sort(() => Math.random() - 0.5);
}
var scienceArr = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
shuffleScienceArray(scienceArr);

//History Array
function shuffleHistoryArray(array) {
  array.sort(() => Math.random() - 0.5);
}
var historyArr = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
shuffleHistoryArray(historyArr);

//Movies Array
function shuffleMovieArray(array) {
  array.sort(() => Math.random() - 0.5);
}
var movieArr = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
shuffleMovieArray(movieArr);

//General Knowlege Array
function shuffleGeneralArray(array) {
  array.sort(() => Math.random() - 0.5);
}
var generalArr = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
shuffleGeneralArray(generalArr);

// GEOGRAPHY QUESTION ONE VARIABLES

let geoQuesOne = geographyQuestions[geographyArr[0]].Question;
let geoQuesOneAnswerA = geographyQuestions[geographyArr[0]].OptionA;
let geoQuesOneAnswerB = geographyQuestions[geographyArr[0]].OptionB;
let geoQuesOneAnswerC = geographyQuestions[geographyArr[0]].OptionC;
let geoQuesOneAnswerD = geographyQuestions[geographyArr[0]].OptionD;
let geoQuesOneWrongAnswer = geographyQuestions[geographyArr[0]].WrongAnswerText;
let geoQuesOneCorrectAnswer =
  geographyQuestions[geographyArr[0]].CorrectAnswerText;

//GEOGRAPHY QUESTION TWO VARIABLES

let geoQuesTwo = geographyQuestions[geographyArr[1]].Question;
let geoQuesTwoAnswerA = geographyQuestions[geographyArr[1]].OptionA;
let geoQuesTwoAnswerB = geographyQuestions[geographyArr[1]].OptionB;
let geoQuesTwoAnswerC = geographyQuestions[geographyArr[1]].OptionC;
let geoQuesTwoAnswerD = geographyQuestions[geographyArr[1]].OptionD;
let geoQuesTwoWrongAnswer = geographyQuestions[geographyArr[1]].WrongAnswerText;
let geoQuesTwoCorrectAnswer =
  geographyQuestions[geographyArr[1]].CorrectAnswerText;

//GEOGRAPHY QUESTION THREE VARIABLES

let geoQuesThree = geographyQuestions[geographyArr[2]].Question;
let geoQuesThreeAnswerA = geographyQuestions[geographyArr[2]].OptionA;
let geoQuesThreeAnswerB = geographyQuestions[geographyArr[2]].OptionB;
let geoQuesThreeAnswerC = geographyQuestions[geographyArr[2]].OptionC;
let geoQuesThreeAnswerD = geographyQuestions[geographyArr[2]].OptionD;
let geoQuesThreeWrongAnswer =
  geographyQuestions[geographyArr[2]].WrongAnswerText;
let geoQuesThreeCorrectAnswer =
  geographyQuestions[geographyArr[2]].CorrectAnswerText;

//GEOGRAPHY QUESTION FOUR VARIABLES

let geoQuesFour = geographyQuestions[geographyArr[3]].Question;
let geoQuesFourAnswerA = geographyQuestions[geographyArr[3]].OptionA;
let geoQuesFourAnswerB = geographyQuestions[geographyArr[3]].OptionB;
let geoQuesFourAnswerC = geographyQuestions[geographyArr[3]].OptionC;
let geoQuesFourAnswerD = geographyQuestions[geographyArr[3]].OptionD;
let geoQuesFourWrongAnswer =
  geographyQuestions[geographyArr[3]].WrongAnswerText;
let geoQuesFourCorrectAnswer =
  geographyQuestions[geographyArr[3]].CorrectAnswerText;

//GEOGRAPHY QUESTION FIVE VARIABLES

let geoQuesFive = geographyQuestions[geographyArr[4]].Question;
let geoQuesFiveAnswerA = geographyQuestions[geographyArr[4]].OptionA;
let geoQuesFiveAnswerB = geographyQuestions[geographyArr[4]].OptionB;
let geoQuesFiveAnswerC = geographyQuestions[geographyArr[4]].OptionC;
let geoQuesFiveAnswerD = geographyQuestions[geographyArr[4]].OptionD;
let geoQuesFiveWrongAnswer =
  geographyQuestions[geographyArr[4]].WrongAnswerText;
let geoQuesFiveCorrectAnswer =
  geographyQuestions[geographyArr[4]].CorrectAnswerText;

//GEOGRAPHY QUESTION SIX VARIABLES

let geoQuesSix = geographyQuestions[geographyArr[5]].Question;
let geoQuesSixAnswerA = geographyQuestions[geographyArr[5]].OptionA;
let geoQuesSixAnswerB = geographyQuestions[geographyArr[5]].OptionB;
let geoQuesSixAnswerC = geographyQuestions[geographyArr[5]].OptionC;
let geoQuesSixAnswerD = geographyQuestions[geographyArr[5]].OptionD;
let geoQuesSixWrongAnswer = geographyQuestions[geographyArr[5]].WrongAnswerText;
let geoQuesSixCorrectAnswer =
  geographyQuestions[geographyArr[5]].CorrectAnswerText;

//Geography Round Functions

//GEOGRAPHY QUESTION ONE

function geographyQuestionOne() {
  launchGame();
  startBtn.addEventListener("click", resetGame);
  alert("Geography Round! Are You Ready?!");
  buttonContent(
    geoQuesOneAnswerA,
    geoQuesOneAnswerB,
    geoQuesOneAnswerC,
    geoQuesOneAnswerD
  );

  addListeners(
    "click",
    geoQuesOneButtonA,
    geoQuesOneButtonB,
    geoQuesOneButtonC,
    geoQuesOneButtonD
  );
}

function geoQuesOneButtonA() {
  if (geographyQuestions[geographyArr[0]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${geoQuesOneCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionTwo);
  } else {
    gameText.innerHTML = `<h3>geoQuesTwoWrongAnswer</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionTwo);
  }
}

function geoQuesOneButtonB() {
  if (geographyQuestions[geographyArr[0]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${geoQuesOneCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionTwo);
  } else {
    gameText.innerHTML = `<h3>${geoQuesOneWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionTwo);
  }
}

function geoQuesOneButtonC() {
  if (geographyQuestions[geographyArr[0]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${geoQuesOneCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionTwo);
  } else {
    gameText.innerHTML = `<h3>${geoQuesOneWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionTwo);
  }
}

function geoQuesOneButtonD() {
  if (geographyQuestions[geographyArr[0]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${geoQuesOneCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionTwo);
  } else {
    gameText.innerHTML = `<h3>${geoQuesOneWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionTwo);
  }
}

//GEOGRAPHY QUESTION TWO

function geographyQuestionTwo() {
  removeListeners(
    "click",
    geoQuesOneButtonA,
    geoQuesOneButtonB,
    geoQuesOneButtonC,
    geoQuesOneButtonD,
    geographyQuestionTwo
  );

  category.innerHTML = `<h5>Geography</h5>`;
  questionNum.innerHTML = `<h5>Question 2</h5>`;
  gameText.innerHTML = `<h3>${geoQuesTwo}</h3>`;
  defaultSetting();

  //Buttons
  buttonContent(
    geoQuesTwoAnswerA,
    geoQuesTwoAnswerB,
    geoQuesTwoAnswerC,
    geoQuesTwoAnswerD
  );

  addListeners(
    "click",
    geoQuesTwoButtonA,
    geoQuesTwoButtonB,
    geoQuesTwoButtonC,
    geoQuesTwoButtonD
  );
}

function geoQuesTwoButtonA() {
  if (geographyQuestions[geographyArr[1]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${geoQuesTwoCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionThree);
  } else {
    gameText.innerHTML = `<h3>geoQuesTwoWrongAnswer</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionThree);
  }
}

function geoQuesTwoButtonB() {
  if (geographyQuestions[geographyArr[1]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${geoQuesTwoCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionThree);
  } else {
    gameText.innerHTML = `<h3>${geoQuesTwoWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionThree);
  }
}

function geoQuesTwoButtonC() {
  if (geographyQuestions[geographyArr[1]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${geoQuesTwoCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionThree);
  } else {
    gameText.innerHTML = `<h3>${geoQuesTwoWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionThree);
  }
}

function geoQuesTwoButtonD() {
  if (geographyQuestions[geographyArr[1]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${geoQuesTwoCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionThree);
  } else {
    gameText.innerHTML = `<h3>${geoQuesTwoWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionThree);
  }
}

//GEOGRAPHY QUESTION THREE

//GEOGRAPHY QUESTION THREE
function geographyQuestionThree() {
  removeListeners(
    "click",
    geoQuesTwoButtonA,
    geoQuesTwoButtonB,
    geoQuesTwoButtonC,
    geoQuesTwoButtonD,
    geographyQuestionThree
  );

  category.innerHTML = `<h5>Geography</h5>`;
  questionNum.innerHTML = `<h5>Question 3</h5>`;
  gameText.innerHTML = `<h3>${geoQuesThree}</h3>`;
  defaultSetting();

  //Buttons
  buttonContent(
    geoQuesThreeAnswerA,
    geoQuesThreeAnswerB,
    geoQuesThreeAnswerC,
    geoQuesThreeAnswerD
  );

  addListeners(
    "click",
    geoQuesThreeButtonA,
    geoQuesThreeButtonB,
    geoQuesThreeButtonC,
    geoQuesThreeButtonD
  );
}

function geoQuesThreeButtonA() {
  if (geographyQuestions[geographyArr[2]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${geoQuesThreeCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionFour);
  } else {
    gameText.innerHTML = `<h3>geoQuesThreeWrongAnswer</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionFour);
  }
}

function geoQuesThreeButtonB() {
  if (geographyQuestions[geographyArr[2]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${geoQuesThreeCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionFour);
  } else {
    gameText.innerHTML = `<h3>${geoQuesThreeWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionFour);
  }
}

function geoQuesThreeButtonC() {
  if (geographyQuestions[geographyArr[2]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${geoQuesThreeCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionFour);
  } else {
    gameText.innerHTML = `<h3>${geoQuesThreeWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionFour);
  }
}

function geoQuesThreeButtonD() {
  if (geographyQuestions[geographyArr[2]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${geoQuesThreeCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionFour);
  } else {
    gameText.innerHTML = `<h3>${geoQuesThreeWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionFour);
  }
}

//GEOGRAPHY QUESTION FOUR
function geographyQuestionFour() {
  removeListeners(
    "click",
    geoQuesThreeButtonA,
    geoQuesThreeButtonB,
    geoQuesThreeButtonC,
    geoQuesThreeButtonD,
    geographyQuestionFour
  );

  category.innerHTML = `<h5>Geography</h5>`;
  questionNum.innerHTML = `<h5>Question 4</h5>`;
  gameText.innerHTML = `<h3>${geoQuesFour}</h3>`;
  defaultSetting();

  //Buttons
  buttonContent(
    geoQuesFourAnswerA,
    geoQuesFourAnswerB,
    geoQuesFourAnswerC,
    geoQuesFourAnswerD
  );

  addListeners(
    "click",
    geoQuesFourButtonA,
    geoQuesFourButtonB,
    geoQuesFourButtonC,
    geoQuesFourButtonD
  );
}

function geoQuesFourButtonA() {
  if (geographyQuestions[geographyArr[3]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${geoQuesFourCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionFive);
  } else {
    gameText.innerHTML = `<h3>${geoQuesFourWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionFive);
  }
}

function geoQuesFourButtonB() {
  if (geographyQuestions[geographyArr[3]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${geoQuesFourCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionFive);
  } else {
    gameText.innerHTML = `<h3>${geoQuesFourWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionFive);
  }
}

function geoQuesFourButtonC() {
  if (geographyQuestions[geographyArr[3]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${geoQuesFourCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionFive);
  } else {
    gameText.innerHTML = `<h3>${geoQuesFourWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionFive);
  }
}

function geoQuesFourButtonD() {
  if (geographyQuestions[geographyArr[3]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${geoQuesFourCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionFive);
  } else {
    gameText.innerHTML = `<h3>${geoQuesFourWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionFive);
  }
}

//GEOGRAPHY QUESTION FIVE
function geographyQuestionFive() {
  removeListeners(
    "click",
    geoQuesFourButtonA,
    geoQuesFourButtonB,
    geoQuesFourButtonC,
    geoQuesFourButtonD,
    geographyQuestionFive
  );

  category.innerHTML = `<h5>Geography</h5>`;
  questionNum.innerHTML = `<h5>Question 5</h5>`;
  gameText.innerHTML = `<h3>${geoQuesFive}</h3>`;
  defaultSetting();

  //Buttons
  buttonContent(
    geoQuesFiveAnswerA,
    geoQuesFiveAnswerB,
    geoQuesFiveAnswerC,
    geoQuesFiveAnswerD
  );

  addListeners(
    "click",
    geoQuesFiveButtonA,
    geoQuesFiveButtonB,
    geoQuesFiveButtonC,
    geoQuesFiveButtonD
  );
}

function geoQuesFiveButtonA() {
  if (geographyQuestions[geographyArr[4]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${geoQuesFiveCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionSix);
  } else {
    gameText.innerHTML = `<h3>${geoQuesFiveWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionSix);
  }
}

function geoQuesFiveButtonB() {
  if (geographyQuestions[geographyArr[4]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${geoQuesFiveCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionSix);
  } else {
    gameText.innerHTML = `<h3>${geoQuesFiveWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionSix);
  }
}

function geoQuesFiveButtonC() {
  if (geographyQuestions[geographyArr[4]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${geoQuesFiveCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionSix);
  } else {
    gameText.innerHTML = `<h3>${geoQuesFiveWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionSix);
  }
}

function geoQuesFiveButtonD() {
  if (geographyQuestions[geographyArr[4]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${geoQuesFiveCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionSix);
  } else {
    gameText.innerHTML = `<h3>${geoQuesFiveWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", geographyQuestionSix);
  }
}

//GEOGRAPHY QUESTION SIX
function geographyQuestionSix() {
  removeListeners(
    "click",
    geoQuesFiveButtonA,
    geoQuesFiveButtonB,
    geoQuesFiveButtonC,
    geoQuesFiveButtonD,
    geographyQuestionSix
  );

  category.innerHTML = `<h5>Geography</h5>`;
  questionNum.innerHTML = `<h5>Question 6</h5>`;
  gameText.innerHTML = `<h3>${geoQuesSix}</h3>`;
  defaultSetting();

  //Buttons

  buttonContent(
    geoQuesSixAnswerA,
    geoQuesSixAnswerB,
    geoQuesSixAnswerC,
    geoQuesSixAnswerD
  );

  addListeners(
    "click",
    geoQuesSixButtonA,
    geoQuesSixButtonB,
    geoQuesSixButtonC,
    geoQuesSixButtonD
  );
}

function geoQuesSixButtonA() {
  if (geographyQuestions[geographyArr[5]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${geoQuesSixCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionOne);
  } else {
    gameText.innerHTML = `<h3>${geoQuesSixWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionOne);
  }
}

function geoQuesSixButtonB() {
  if (geographyQuestions[geographyArr[5]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${geoQuesSixCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionOne);
  } else {
    gameText.innerHTML = `<h3>${geoQuesSixWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionOne);
  }
}

function geoQuesSixButtonC() {
  if (geographyQuestions[geographyArr[5]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${geoQuesSixCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionOne);
  } else {
    gameText.innerHTML = `<h3>${geoQuesSixWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionOne);
  }
}

function geoQuesSixButtonD() {
  if (geographyQuestions[geographyArr[5]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${geoQuesSixCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionOne);
  } else {
    gameText.innerHTML = `<h3>${geoQuesSixWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionOne);
  }
}

//SCIENCE QUESTION ONE VARIABLES

let sciQuesOne = scienceQuestions[scienceArr[0]].Question;
let sciQuesOneAnswerA = scienceQuestions[scienceArr[0]].OptionA;
let sciQuesOneAnswerB = scienceQuestions[scienceArr[0]].OptionB;
let sciQuesOneAnswerC = scienceQuestions[scienceArr[0]].OptionC;
let sciQuesOneAnswerD = scienceQuestions[scienceArr[0]].OptionD;
let sciQuesOneWrongAnswer = scienceQuestions[scienceArr[0]].WrongAnswerText;
let sciQuesOneCorrectAnswer = scienceQuestions[scienceArr[0]].CorrectAnswerText;

//SCIENCE QUESTION TWO VARIABLES

let sciQuesTwo = scienceQuestions[scienceArr[1]].Question;
let sciQuesTwoAnswerA = scienceQuestions[scienceArr[1]].OptionA;
let sciQuesTwoAnswerB = scienceQuestions[scienceArr[1]].OptionB;
let sciQuesTwoAnswerC = scienceQuestions[scienceArr[1]].OptionC;
let sciQuesTwoAnswerD = scienceQuestions[scienceArr[1]].OptionD;
let sciQuesTwoWrongAnswer = scienceQuestions[scienceArr[1]].WrongAnswerText;
let sciQuesTwoCorrectAnswer = scienceQuestions[scienceArr[1]].CorrectAnswerText;

//SCIENCE QUESTION THREE VARIABLES

let sciQuesThree = scienceQuestions[scienceArr[2]].Question;
let sciQuesThreeAnswerA = scienceQuestions[scienceArr[2]].OptionA;
let sciQuesThreeAnswerB = scienceQuestions[scienceArr[2]].OptionB;
let sciQuesThreeAnswerC = scienceQuestions[scienceArr[2]].OptionC;
let sciQuesThreeAnswerD = scienceQuestions[scienceArr[2]].OptionD;
let sciQuesThreeWrongAnswer = scienceQuestions[scienceArr[2]].WrongAnswerText;
let sciQuesThreeCorrectAnswer =
  scienceQuestions[scienceArr[2]].CorrectAnswerText;

//SCIENCE QUESTION FOUR VARIABLES

let sciQuesFour = scienceQuestions[scienceArr[3]].Question;
let sciQuesFourAnswerA = scienceQuestions[scienceArr[3]].OptionA;
let sciQuesFourAnswerB = scienceQuestions[scienceArr[3]].OptionB;
let sciQuesFourAnswerC = scienceQuestions[scienceArr[3]].OptionC;
let sciQuesFourAnswerD = scienceQuestions[scienceArr[3]].OptionD;
let sciQuesFourWrongAnswer = scienceQuestions[scienceArr[3]].WrongAnswerText;
let sciQuesFourCorrectAnswer =
  scienceQuestions[scienceArr[3]].CorrectAnswerText;

//SCIENCE QUESTION FIVE VARIABLES

let sciQuesFive = scienceQuestions[scienceArr[4]].Question;
let sciQuesFiveAnswerA = scienceQuestions[scienceArr[4]].OptionA;
let sciQuesFiveAnswerB = scienceQuestions[scienceArr[4]].OptionB;
let sciQuesFiveAnswerC = scienceQuestions[scienceArr[4]].OptionC;
let sciQuesFiveAnswerD = scienceQuestions[scienceArr[4]].OptionD;
let sciQuesFiveWrongAnswer = scienceQuestions[scienceArr[4]].WrongAnswerText;
let sciQuesFiveCorrectAnswer =
  scienceQuestions[scienceArr[4]].CorrectAnswerText;

//SCIENCE QUESTION SIX VARIABLES

let sciQuesSix = scienceQuestions[scienceArr[5]].Question;
let sciQuesSixAnswerA = scienceQuestions[scienceArr[5]].OptionA;
let sciQuesSixAnswerB = scienceQuestions[scienceArr[5]].OptionB;
let sciQuesSixAnswerC = scienceQuestions[scienceArr[5]].OptionC;
let sciQuesSixAnswerD = scienceQuestions[scienceArr[5]].OptionD;
let sciQuesSixWrongAnswer = scienceQuestions[scienceArr[5]].WrongAnswerText;
let sciQuesSixCorrectAnswer = scienceQuestions[scienceArr[5]].CorrectAnswerText;

//SCIENCE QUESTION ONE
function scienceQuestionOne() {
  removeListeners(
    "click",
    geoQuesSixButtonA,
    geoQuesSixButtonB,
    geoQuesSixButtonC,
    geoQuesSixButtonD,
    scienceQuestionOne
  );

  category.innerHTML = `<h5>Science</h5>`;
  questionNum.innerHTML = `<h5>Question 7</h5>`;
  gameText.innerHTML = `<h3>${sciQuesOne}</h3>`;
  alert("Science Round! Are You Ready?!");
  defaultSetting();

  //Buttons
  buttonContent(
    sciQuesOneAnswerA,
    sciQuesOneAnswerB,
    sciQuesOneAnswerC,
    sciQuesOneAnswerD
  );

  addListeners(
    "click",
    sciQuesOneButtonA,
    sciQuesOneButtonB,
    sciQuesOneButtonC,
    sciQuesOneButtonD
  );
}

function sciQuesOneButtonA() {
  if (scienceQuestions[scienceArr[0]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${sciQuesOneCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionTwo);
  } else {
    gameText.innerHTML = `<h3>${sciQuesOneWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionTwo);
  }
}

function sciQuesOneButtonB() {
  if (scienceQuestions[scienceArr[0]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${sciQuesOneCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionTwo);
  } else {
    gameText.innerHTML = `<h3>${sciQuesOneWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionTwo);
  }
}

function sciQuesOneButtonC() {
  if (scienceQuestions[scienceArr[0]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${sciQuesOneCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionTwo);
  } else {
    gameText.innerHTML = `<h3>${sciQuesOneWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionTwo);
  }
}

function sciQuesOneButtonD() {
  if (scienceQuestions[scienceArr[0]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${sciQuesOneCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionTwo);
  } else {
    gameText.innerHTML = `<h3>${sciQuesOneWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionTwo);
  }
}

//SCIENCE QUESTION TWO

function scienceQuestionTwo() {
  removeListeners(
    "click",
    sciQuesOneButtonA,
    sciQuesOneButtonB,
    sciQuesOneButtonC,
    sciQuesOneButtonD,
    scienceQuestionTwo
  );

  category.innerHTML = `<h5>Science</h5>`;
  questionNum.innerHTML = `<h5>Question 8</h5>`;
  gameText.innerHTML = `<h3>${sciQuesTwo}</h3>`;
  defaultSetting();

  //Buttons
  buttonContent(
    sciQuesTwoAnswerA,
    sciQuesTwoAnswerB,
    sciQuesTwoAnswerC,
    sciQuesTwoAnswerD
  );

  addListeners(
    "click",
    sciQuesTwoButtonA,
    sciQuesTwoButtonB,
    sciQuesTwoButtonC,
    sciQuesTwoButtonD
  );
}

function sciQuesTwoButtonA() {
  if (scienceQuestions[scienceArr[1]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${sciQuesTwoCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionThree);
  } else {
    gameText.innerHTML = `<h3>${sciQuesTwoWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionThree);
  }
}

function sciQuesTwoButtonB() {
  if (scienceQuestions[scienceArr[1]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${sciQuesTwoCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionThree);
  } else {
    gameText.innerHTML = `<h3>${sciQuesTwoWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionThree);
  }
}

function sciQuesTwoButtonC() {
  if (scienceQuestions[scienceArr[1]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${sciQuesTwoCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionThree);
  } else {
    gameText.innerHTML = `<h3>${sciQuesTwoWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionThree);
  }
}

function sciQuesTwoButtonD() {
  if (scienceQuestions[scienceArr[1]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${sciQuesTwoCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionThree);
  } else {
    gameText.innerHTML = `<h3>${sciQuesTwoWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionThree);
  }
}

//SCIENCE QUESTION THREE

function scienceQuestionThree() {
  removeListeners(
    "click",
    sciQuesTwoButtonA,
    sciQuesTwoButtonB,
    sciQuesTwoButtonC,
    sciQuesTwoButtonD,
    scienceQuestionThree
  );

  category.innerHTML = `<h5>Science</h5>`;
  questionNum.innerHTML = `<h5>Question 9</h5>`;
  gameText.innerHTML = `<h3>${sciQuesThree}</h3>`;
  defaultSetting();

  //Buttons
  buttonContent(
    sciQuesThreeAnswerA,
    sciQuesThreeAnswerB,
    sciQuesThreeAnswerC,
    sciQuesThreeAnswerD
  );

  addListeners(
    "click",
    sciQuesThreeButtonA,
    sciQuesThreeButtonB,
    sciQuesThreeButtonC,
    sciQuesThreeButtonD
  );
}

function sciQuesThreeButtonA() {
  if (scienceQuestions[scienceArr[2]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${sciQuesThreeCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionFour);
  } else {
    gameText.innerHTML = `<h3>${sciQuesThreeWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionFour);
  }
}

function sciQuesThreeButtonB() {
  if (scienceQuestions[scienceArr[2]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${sciQuesThreeCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionFour);
  } else {
    gameText.innerHTML = `<h3>${sciQuesThreeWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionFour);
  }
}

function sciQuesThreeButtonC() {
  if (scienceQuestions[scienceArr[2]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${sciQuesThreeCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionFour);
  } else {
    gameText.innerHTML = `<h3>${sciQuesThreeWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionFour);
  }
}

function sciQuesThreeButtonD() {
  if (scienceQuestions[scienceArr[2]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${sciQuesThreeCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionFour);
  } else {
    gameText.innerHTML = `<h3>${sciQuesThreeWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionFour);
  }
}

//SCIENCE QUESTION FOUR

function scienceQuestionFour() {
  removeListeners(
    "click",
    sciQuesThreeButtonA,
    sciQuesThreeButtonB,
    sciQuesThreeButtonC,
    sciQuesThreeButtonD,
    scienceQuestionFour
  );

  category.innerHTML = `<h5>Science</h5>`;
  questionNum.innerHTML = `<h5>Question 10</h5>`;
  gameText.innerHTML = `<h3>${sciQuesFour}</h3>`;
  defaultSetting();

  //Buttons
  buttonContent(
    sciQuesFourAnswerA,
    sciQuesFourAnswerB,
    sciQuesFourAnswerC,
    sciQuesFourAnswerD
  );

  addListeners(
    "click",
    sciQuesFourButtonA,
    sciQuesFourButtonB,
    sciQuesFourButtonC,
    sciQuesFourButtonD
  );
}

function sciQuesFourButtonA() {
  if (scienceQuestions[scienceArr[3]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${sciQuesFourCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionFive);
  } else {
    gameText.innerHTML = `<h3>${sciQuesFourWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionFive);
  }
}

function sciQuesFourButtonB() {
  if (scienceQuestions[scienceArr[3]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${sciQuesFourCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionFive);
  } else {
    gameText.innerHTML = `<h3>${sciQuesFourWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionFive);
  }
}

function sciQuesFourButtonC() {
  if (scienceQuestions[scienceArr[3]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${sciQuesFourCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionFive);
  } else {
    gameText.innerHTML = `<h3>${sciQuesFourWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionFive);
  }
}

function sciQuesFourButtonD() {
  if (scienceQuestions[scienceArr[3]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${sciQuesFourCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionFive);
  } else {
    gameText.innerHTML = `<h3>${sciQuesFourWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionFive);
  }
}

//SCIENCE QUESTION FIVE

function scienceQuestionFive() {
  removeListeners(
    "click",
    sciQuesFourButtonA,
    sciQuesFourButtonB,
    sciQuesFourButtonC,
    sciQuesFourButtonD,
    scienceQuestionFive
  );

  category.innerHTML = `<h5>Science</h5>`;
  questionNum.innerHTML = `<h5>Question 11</h5>`;
  gameText.innerHTML = `<h3>${sciQuesFive}</h3>`;
  defaultSetting();

  //Buttons
  buttonContent(
    sciQuesFiveAnswerA,
    sciQuesFiveAnswerB,
    sciQuesFiveAnswerC,
    sciQuesFiveAnswerD
  );

  addListeners(
    "click",
    sciQuesFiveButtonA,
    sciQuesFiveButtonB,
    sciQuesFiveButtonC,
    sciQuesFiveButtonD
  );
}

function sciQuesFiveButtonA() {
  if (scienceQuestions[scienceArr[4]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${sciQuesFiveCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionSix);
  } else {
    gameText.innerHTML = `<h3>${sciQuesFiveWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionSix);
  }
}

function sciQuesFiveButtonB() {
  if (scienceQuestions[scienceArr[4]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${sciQuesFiveCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionSix);
  } else {
    gameText.innerHTML = `<h3>${sciQuesFiveWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionSix);
  }
}

function sciQuesFiveButtonC() {
  if (scienceQuestions[scienceArr[4]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${sciQuesFiveCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionSix);
  } else {
    gameText.innerHTML = `<h3>${sciQuesFiveWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionSix);
  }
}

function sciQuesFiveButtonD() {
  if (scienceQuestions[scienceArr[4]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${sciQuesFiveCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionSix);
  } else {
    gameText.innerHTML = `<h3>${sciQuesFiveWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", scienceQuestionSix);
  }
}

//SCIENCE QUESTION FIVE

function scienceQuestionSix() {
  removeListeners(
    "click",
    sciQuesFiveButtonA,
    sciQuesFiveButtonB,
    sciQuesFiveButtonC,
    sciQuesFiveButtonD,
    scienceQuestionSix
  );

  category.innerHTML = `<h5>Science</h5>`;
  questionNum.innerHTML = `<h5>Question 12</h5>`;
  gameText.innerHTML = `<h3>${sciQuesSix}</h3>`;
  defaultSetting();

  //Buttons
  buttonContent(
    sciQuesSixAnswerA,
    sciQuesSixAnswerB,
    sciQuesSixAnswerC,
    sciQuesSixAnswerD
  );

  addListeners(
    "click",
    sciQuesSixButtonA,
    sciQuesSixButtonB,
    sciQuesSixButtonC,
    sciQuesSixButtonD
  );
}

function sciQuesSixButtonA() {
  if (scienceQuestions[scienceArr[5]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${sciQuesSixCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionOne);
  } else {
    gameText.innerHTML = `<h3>${sciQuesSixWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionOne);
  }
}

function sciQuesSixButtonB() {
  if (scienceQuestions[scienceArr[5]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${sciQuesSixCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionOne);
  } else {
    gameText.innerHTML = `<h3>${sciQuesSixWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionOne);
  }
}

function sciQuesSixButtonC() {
  if (scienceQuestions[scienceArr[5]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${sciQuesSixCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionOne);
  } else {
    gameText.innerHTML = `<h3>${sciQuesSixWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionOne);
  }
}

function sciQuesSixButtonD() {
  if (scienceQuestions[scienceArr[5]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${sciQuesSixCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionOne);
  } else {
    gameText.innerHTML = `<h3>${sciQuesSixWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionOne);
  }
}

//HISTORY ROUND!

//HISTORY QUESTION ONE VARIABLES

let hisQuesOne = historyQuestions[historyArr[0]].Question;
let hisQuesOneAnswerA = historyQuestions[historyArr[0]].OptionA;
let hisQuesOneAnswerB = historyQuestions[historyArr[0]].OptionB;
let hisQuesOneAnswerC = historyQuestions[historyArr[0]].OptionC;
let hisQuesOneAnswerD = historyQuestions[historyArr[0]].OptionD;
let hisQuesOneWrongAnswer = historyQuestions[historyArr[0]].WrongAnswerText;
let hisQuesOneCorrectAnswer = historyQuestions[historyArr[0]].CorrectAnswerText;

//HISTORY QUESTION TWO VARIABLES

let hisQuesTwo = historyQuestions[historyArr[1]].Question;
let hisQuesTwoAnswerA = historyQuestions[historyArr[1]].OptionA;
let hisQuesTwoAnswerB = historyQuestions[historyArr[1]].OptionB;
let hisQuesTwoAnswerC = historyQuestions[historyArr[1]].OptionC;
let hisQuesTwoAnswerD = historyQuestions[historyArr[1]].OptionD;
let hisQuesTwoWrongAnswer = historyQuestions[historyArr[1]].WrongAnswerText;
let hisQuesTwoCorrectAnswer = historyQuestions[historyArr[1]].CorrectAnswerText;

//HISTORY QUESTION THREE VARIABLES

let hisQuesThree = historyQuestions[historyArr[2]].Question;
let hisQuesThreeAnswerA = historyQuestions[historyArr[2]].OptionA;
let hisQuesThreeAnswerB = historyQuestions[historyArr[2]].OptionB;
let hisQuesThreeAnswerC = historyQuestions[historyArr[2]].OptionC;
let hisQuesThreeAnswerD = historyQuestions[historyArr[2]].OptionD;
let hisQuesThreeWrongAnswer = historyQuestions[historyArr[2]].WrongAnswerText;
let hisQuesThreeCorrectAnswer =
  historyQuestions[historyArr[2]].CorrectAnswerText;

//HISTORY QUESTION FOUR VARIABLES

let hisQuesFour = historyQuestions[historyArr[3]].Question;
let hisQuesFourAnswerA = historyQuestions[historyArr[3]].OptionA;
let hisQuesFourAnswerB = historyQuestions[historyArr[3]].OptionB;
let hisQuesFourAnswerC = historyQuestions[historyArr[3]].OptionC;
let hisQuesFourAnswerD = historyQuestions[historyArr[3]].OptionD;
let hisQuesFourWrongAnswer = historyQuestions[historyArr[3]].WrongAnswerText;
let hisQuesFourCorrectAnswer =
  historyQuestions[historyArr[3]].CorrectAnswerText;

//HISTORY QUESTION FIVE VARIABLES

let hisQuesFive = historyQuestions[historyArr[4]].Question;
let hisQuesFiveAnswerA = historyQuestions[historyArr[4]].OptionA;
let hisQuesFiveAnswerB = historyQuestions[historyArr[4]].OptionB;
let hisQuesFiveAnswerC = historyQuestions[historyArr[4]].OptionC;
let hisQuesFiveAnswerD = historyQuestions[historyArr[4]].OptionD;
let hisQuesFiveWrongAnswer = historyQuestions[historyArr[4]].WrongAnswerText;
let hisQuesFiveCorrectAnswer =
  historyQuestions[historyArr[4]].CorrectAnswerText;

//HISTORY QUESTION SIX VARIABLES

let hisQuesSix = historyQuestions[historyArr[5]].Question;
let hisQuesSixAnswerA = historyQuestions[historyArr[5]].OptionA;
let hisQuesSixAnswerB = historyQuestions[historyArr[5]].OptionB;
let hisQuesSixAnswerC = historyQuestions[historyArr[5]].OptionC;
let hisQuesSixAnswerD = historyQuestions[historyArr[5]].OptionD;
let hisQuesSixWrongAnswer = historyQuestions[historyArr[5]].WrongAnswerText;
let hisQuesSixCorrectAnswer = historyQuestions[historyArr[5]].CorrectAnswerText;

//SCIENCE QUESTION FIVE

function historyQuestionOne() {
  removeListeners(
    "click",
    sciQuesSixButtonA,
    sciQuesSixButtonB,
    sciQuesSixButtonC,
    sciQuesSixButtonD,
    historyQuestionOne
  );

  category.innerHTML = `<h5>History</h5>`;
  questionNum.innerHTML = `<h5>Question 13</h5>`;
  gameText.innerHTML = `<h3>${hisQuesOne}</h3>`;
  alert("History Round! Are You Ready?!");
  defaultSetting();

  //Buttons
  buttonContent(
    hisQuesOneAnswerA,
    hisQuesOneAnswerB,
    hisQuesOneAnswerC,
    hisQuesOneAnswerD
  );

  addListeners(
    "click",
    hisQuesOneButtonA,
    hisQuesOneButtonB,
    hisQuesOneButtonC,
    hisQuesOneButtonD
  );
}

function hisQuesOneButtonA() {
  if (historyQuestions[historyArr[0]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${hisQuesOneCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionTwo);
  } else {
    gameText.innerHTML = `<h3>${hisQuesOneWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionTwo);
  }
}

function hisQuesOneButtonB() {
  if (historyQuestions[historyArr[0]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${hisQuesOneCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionTwo);
  } else {
    gameText.innerHTML = `<h3>${hisQuesOneWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionTwo);
  }
}

function hisQuesOneButtonC() {
  if (historyQuestions[historyArr[0]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${hisQuesOneCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionTwo);
  } else {
    gameText.innerHTML = `<h3>${hisQuesOneWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionTwo);
  }
}

function hisQuesOneButtonD() {
  if (historyQuestions[historyArr[0]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${hisQuesOneCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionTwo);
  } else {
    gameText.innerHTML = `<h3>${hisQuesOneWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionTwo);
  }
}

function historyQuestionTwo() {
  removeListeners(
    "click",
    hisQuesOneButtonA,
    hisQuesOneButtonB,
    hisQuesOneButtonC,
    hisQuesOneButtonD,
    historyQuestionTwo
  );

  questionNum.innerHTML = `<h5>Question 14</h5>`;
  gameText.innerHTML = `<h3>${hisQuesTwo}</h3>`;
  defaultSetting();

  //Buttons
  buttonContent(
    hisQuesTwoAnswerA,
    hisQuesTwoAnswerB,
    hisQuesTwoAnswerC,
    hisQuesTwoAnswerD
  );

  addListeners(
    "click",
    hisQuesTwoButtonA,
    hisQuesTwoButtonB,
    hisQuesTwoButtonC,
    hisQuesTwoButtonD
  );
}

function hisQuesTwoButtonA() {
  if (historyQuestions[historyArr[1]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${hisQuesTwoCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionThree);
  } else {
    gameText.innerHTML = `<h3>${hisQuesTwoWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionThree);
  }
}

function hisQuesTwoButtonB() {
  if (historyQuestions[historyArr[1]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${hisQuesTwoCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionThree);
  } else {
    gameText.innerHTML = `<h3>${hisQuesTwoWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionThree);
  }
}

function hisQuesTwoButtonC() {
  if (historyQuestions[historyArr[1]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${hisQuesTwoCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionThree);
  } else {
    gameText.innerHTML = `<h3>${hisQuesTwoWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionThree);
  }
}

function hisQuesTwoButtonD() {
  if (historyQuestions[historyArr[1]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${hisQuesTwoCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionThree);
  } else {
    gameText.innerHTML = `<h3>${hisQuesTwoWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionThree);
  }
}

function historyQuestionThree() {
  removeListeners(
    "click",
    hisQuesTwoButtonA,
    hisQuesTwoButtonB,
    hisQuesTwoButtonC,
    hisQuesTwoButtonD,
    historyQuestionThree
  );

  questionNum.innerHTML = `<h5>Question 14</h5>`;
  gameText.innerHTML = `<h3>${hisQuesThree}</h3>`;
  defaultSetting();

  //Buttons
  buttonContent(
    hisQuesThreeAnswerA,
    hisQuesThreeAnswerB,
    hisQuesThreeAnswerC,
    hisQuesThreeAnswerD
  );

  addListeners(
    "click",
    hisQuesThreeButtonA,
    hisQuesThreeButtonB,
    hisQuesThreeButtonC,
    hisQuesThreeButtonD
  );
}

function hisQuesThreeButtonA() {
  if (historyQuestions[historyArr[2]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${hisQuesThreeCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionFour);
  } else {
    gameText.innerHTML = `<h3>${hisQuesThreeWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionFour);
  }
}

function hisQuesThreeButtonB() {
  if (historyQuestions[historyArr[2]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${hisQuesThreeCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionFour);
  } else {
    gameText.innerHTML = `<h3>${hisQuesThreeWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionFour);
  }
}

function hisQuesThreeButtonC() {
  if (historyQuestions[historyArr[2]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${hisQuesThreeCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionFour);
  } else {
    gameText.innerHTML = `<h3>${hisQuesThreeWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionFour);
  }
}

function hisQuesThreeButtonD() {
  if (historyQuestions[historyArr[2]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${hisQuesThreeCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionFour);
  } else {
    gameText.innerHTML = `<h3>${hisQuesThreeWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionFour);
  }
}

function historyQuestionFour() {
  removeListeners(
    "click",
    hisQuesThreeButtonA,
    hisQuesThreeButtonB,
    hisQuesThreeButtonC,
    hisQuesThreeButtonD,
    historyQuestionFour
  );

  questionNum.innerHTML = `<h5>Question 15</h5>`;
  gameText.innerHTML = `<h3>${hisQuesFour}</h3>`;
  defaultSetting();

  //Buttons
  buttonContent(
    hisQuesFourAnswerA,
    hisQuesFourAnswerB,
    hisQuesFourAnswerC,
    hisQuesFourAnswerD
  );

  addListeners(
    "click",
    hisQuesFourButtonA,
    hisQuesFourButtonB,
    hisQuesFourButtonC,
    hisQuesFourButtonD
  );
}

function hisQuesFourButtonA() {
  if (historyQuestions[historyArr[3]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${hisQuesFourCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionFive);
  } else {
    gameText.innerHTML = `<h3>${hisQuesFourWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionFive);
  }
}

function hisQuesFourButtonB() {
  if (historyQuestions[historyArr[3]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${hisQuesFourCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionFive);
  } else {
    gameText.innerHTML = `<h3>${hisQuesFourWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionFive);
  }
}

function hisQuesFourButtonC() {
  if (historyQuestions[historyArr[3]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${hisQuesFourCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionFive);
  } else {
    gameText.innerHTML = `<h3>${hisQuesFourWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionFive);
  }
}

function hisQuesFourButtonD() {
  if (historyQuestions[historyArr[3]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${hisQuesFourCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionFive);
  } else {
    gameText.innerHTML = `<h3>${hisQuesFourWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionFive);
  }
}

function historyQuestionFive() {
  removeListeners(
    "click",
    hisQuesFourButtonA,
    hisQuesFourButtonB,
    hisQuesFourButtonC,
    hisQuesFourButtonD,
    historyQuestionFive
  );

  questionNum.innerHTML = `<h5>Question 16</h5>`;
  gameText.innerHTML = `<h3>${hisQuesFive}</h3>`;
  defaultSetting();

  //Buttons
  buttonContent(
    hisQuesFiveAnswerA,
    hisQuesFiveAnswerB,
    hisQuesFiveAnswerC,
    hisQuesFiveAnswerD
  );

  addListeners(
    "click",
    hisQuesFiveButtonA,
    hisQuesFiveButtonB,
    hisQuesFiveButtonC,
    hisQuesFiveButtonD
  );
}

function hisQuesFiveButtonA() {
  if (historyQuestions[historyArr[4]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${hisQuesFiveCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionSix);
  } else {
    gameText.innerHTML = `<h3>${hisQuesFiveWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionSix);
  }
}

function hisQuesFiveButtonB() {
  if (historyQuestions[historyArr[4]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${hisQuesFiveCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionSix);
  } else {
    gameText.innerHTML = `<h3>${hisQuesFiveWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionSix);
  }
}

function hisQuesFiveButtonC() {
  if (historyQuestions[historyArr[4]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${hisQuesFiveCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionSix);
  } else {
    gameText.innerHTML = `<h3>${hisQuesFiveWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionSix);
  }
}

function hisQuesFiveButtonD() {
  if (historyQuestions[historyArr[4]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${hisQuesFiveCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionSix);
  } else {
    gameText.innerHTML = `<h3>${hisQuesFiveWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", historyQuestionSix);
  }
}

function historyQuestionSix() {
  removeListeners(
    "click",
    hisQuesFiveButtonA,
    hisQuesFiveButtonB,
    hisQuesFiveButtonC,
    hisQuesFiveButtonD,
    historyQuestionSix
  );

  questionNum.innerHTML = `<h5>Question 18</h5>`;
  gameText.innerHTML = `<h3>${hisQuesSix}</h3>`;
  defaultSetting();

  //Buttons
  buttonContent(
    hisQuesSixAnswerA,
    hisQuesSixAnswerB,
    hisQuesSixAnswerC,
    hisQuesSixAnswerD
  );

  addListeners(
    "click",
    hisQuesSixButtonA,
    hisQuesSixButtonB,
    hisQuesSixButtonC,
    hisQuesSixButtonD
  );
}

function hisQuesSixButtonA() {
  if (historyQuestions[historyArr[5]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${hisQuesSixCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionOne);
  } else {
    gameText.innerHTML = `<h3>${hisQuesSixWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionOne);
  }
}

function hisQuesSixButtonB() {
  if (historyQuestions[historyArr[5]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${hisQuesSixCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionOne);
  } else {
    gameText.innerHTML = `<h3>${hisQuesSixWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionOne);
  }
}

function hisQuesSixButtonC() {
  if (historyQuestions[historyArr[5]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${hisQuesSixCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionOne);
  } else {
    gameText.innerHTML = `<h3>${hisQuesSixWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionOne);
  }
}

function hisQuesSixButtonD() {
  if (historyQuestions[historyArr[5]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${hisQuesSixCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionOne);
  } else {
    gameText.innerHTML = `<h3>${hisQuesSixWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionOne);
  }
}

//MOVIE QUESTION ONE VARIABLES

let movQuesOne = movieQuestions[movieArr[0]].Question;
let movQuesOneAnswerA = movieQuestions[movieArr[0]].OptionA;
let movQuesOneAnswerB = movieQuestions[movieArr[0]].OptionB;
let movQuesOneAnswerC = movieQuestions[movieArr[0]].OptionC;
let movQuesOneAnswerD = movieQuestions[movieArr[0]].OptionD;
let movQuesOneWrongAnswer = movieQuestions[movieArr[0]].WrongAnswerText;
let movQuesOneCorrectAnswer = movieQuestions[movieArr[0]].CorrectAnswerText;

//MOVIE QUESTION TWO VARIABLES

let movQuesTwo = movieQuestions[movieArr[1]].Question;
let movQuesTwoAnswerA = movieQuestions[movieArr[1]].OptionA;
let movQuesTwoAnswerB = movieQuestions[movieArr[1]].OptionB;
let movQuesTwoAnswerC = movieQuestions[movieArr[1]].OptionC;
let movQuesTwoAnswerD = movieQuestions[movieArr[1]].OptionD;
let movQuesTwoWrongAnswer = movieQuestions[movieArr[1]].WrongAnswerText;
let movQuesTwoCorrectAnswer = movieQuestions[movieArr[1]].CorrectAnswerText;

//MOVIE QUESTION THREE VARIABLES

let movQuesThree = movieQuestions[movieArr[2]].Question;
let movQuesThreeAnswerA = movieQuestions[movieArr[2]].OptionA;
let movQuesThreeAnswerB = movieQuestions[movieArr[2]].OptionB;
let movQuesThreeAnswerC = movieQuestions[movieArr[2]].OptionC;
let movQuesThreeAnswerD = movieQuestions[movieArr[2]].OptionD;
let movQuesThreeWrongAnswer = movieQuestions[movieArr[2]].WrongAnswerText;
let movQuesThreeCorrectAnswer = movieQuestions[movieArr[2]].CorrectAnswerText;

//MOVIE QUESTION FOUR VARIABLES

let movQuesFour = movieQuestions[movieArr[3]].Question;
let movQuesFourAnswerA = movieQuestions[movieArr[3]].OptionA;
let movQuesFourAnswerB = movieQuestions[movieArr[3]].OptionB;
let movQuesFourAnswerC = movieQuestions[movieArr[3]].OptionC;
let movQuesFourAnswerD = movieQuestions[movieArr[3]].OptionD;
let movQuesFourWrongAnswer = movieQuestions[movieArr[3]].WrongAnswerText;
let movQuesFourCorrectAnswer = movieQuestions[movieArr[3]].CorrectAnswerText;

//MOVIE QUESTION FIVE VARIABLES

let movQuesFive = movieQuestions[movieArr[4]].Question;
let movQuesFiveAnswerA = movieQuestions[movieArr[4]].OptionA;
let movQuesFiveAnswerB = movieQuestions[movieArr[4]].OptionB;
let movQuesFiveAnswerC = movieQuestions[movieArr[4]].OptionC;
let movQuesFiveAnswerD = movieQuestions[movieArr[4]].OptionD;
let movQuesFiveWrongAnswer = movieQuestions[movieArr[4]].WrongAnswerText;
let movQuesFiveCorrectAnswer = movieQuestions[movieArr[4]].CorrectAnswerText;

//MOVIE QUESTION SIX VARIABLES

let movQuesSix = movieQuestions[movieArr[5]].Question;
let movQuesSixAnswerA = movieQuestions[movieArr[5]].OptionA;
let movQuesSixAnswerB = movieQuestions[movieArr[5]].OptionB;
let movQuesSixAnswerC = movieQuestions[movieArr[5]].OptionC;
let movQuesSixAnswerD = movieQuestions[movieArr[5]].OptionD;
let movQuesSixWrongAnswer = movieQuestions[movieArr[5]].WrongAnswerText;
let movQuesSixCorrectAnswer = movieQuestions[movieArr[5]].CorrectAnswerText;

function movieQuestionOne() {
  removeListeners(
    "click",
    hisQuesSixButtonA,
    hisQuesSixButtonB,
    hisQuesSixButtonC,
    hisQuesSixButtonD,
    movieQuestionOne
  );

  category.innerHTML = `<h5>Movies</h5>`;
  questionNum.innerHTML = `<h5>Question 19</h5>`;
  gameText.innerHTML = `<h3>${movQuesOne}</h3>`;
  alert("Time to test your Movie knowledge. Are You Ready?!");
  defaultSetting();

  //Buttons
  buttonContent(
    movQuesOneAnswerA,
    movQuesOneAnswerB,
    movQuesOneAnswerC,
    movQuesOneAnswerD
  );

  addListeners(
    "click",
    movQuesOneButtonA,
    movQuesOneButtonB,
    movQuesOneButtonC,
    movQuesOneButtonD
  );
}

function movQuesOneButtonA() {
  if (movieQuestions[movieArr[0]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${movQuesOneCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionTwo);
  } else {
    gameText.innerHTML = `<h3>${movQuesOneWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionTwo);
  }
}

function movQuesOneButtonB() {
  if (movieQuestions[movieArr[0]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${movQuesOneCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionTwo);
  } else {
    gameText.innerHTML = `<h3>${movQuesOneWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionTwo);
  }
}

function movQuesOneButtonC() {
  if (movieQuestions[movieArr[0]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${movQuesOneCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionTwo);
  } else {
    gameText.innerHTML = `<h3>${movQuesOneWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionTwo);
  }
}

function movQuesOneButtonD() {
  if (movieQuestions[movieArr[0]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${movQuesOneCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionTwo);
  } else {
    gameText.innerHTML = `<h3>${movQuesOneWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionTwo);
  }
}

function movieQuestionTwo() {
  removeListeners(
    "click",
    movQuesOneButtonA,
    movQuesOneButtonB,
    movQuesOneButtonC,
    movQuesOneButtonD,
    movieQuestionTwo
  );

  category.innerHTML = `<h5>Movies</h5>`;
  questionNum.innerHTML = `<h5>Question 20</h5>`;
  gameText.innerHTML = `<h3>${movQuesTwo}</h3>`;
  defaultSetting();

  //Buttons
  buttonContent(
    movQuesTwoAnswerA,
    movQuesTwoAnswerB,
    movQuesTwoAnswerC,
    movQuesTwoAnswerD
  );

  addListeners(
    "click",
    movQuesTwoButtonA,
    movQuesTwoButtonB,
    movQuesTwoButtonC,
    movQuesTwoButtonD
  );
}

function movQuesTwoButtonA() {
  if (movieQuestions[movieArr[1]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${movQuesTwoCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionThree);
  } else {
    gameText.innerHTML = `<h3>${movQuesTwoWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionThree);
  }
}

function movQuesTwoButtonB() {
  if (movieQuestions[movieArr[1]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${movQuesTwoCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionThree);
  } else {
    gameText.innerHTML = `<h3>${movQuesTwoWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionThree);
  }
}

function movQuesTwoButtonC() {
  if (movieQuestions[movieArr[1]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${movQuesTwoCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionThree);
  } else {
    gameText.innerHTML = `<h3>${movQuesTwoWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionThree);
  }
}

function movQuesTwoButtonD() {
  if (movieQuestions[movieArr[1]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${movQuesTwoCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionThree);
  } else {
    gameText.innerHTML = `<h3>${movQuesTwoWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionThree);
  }
}

function movieQuestionThree() {
  removeListeners(
    "click",
    movQuesTwoButtonA,
    movQuesTwoButtonB,
    movQuesTwoButtonC,
    movQuesTwoButtonD,
    movieQuestionThree
  );

  category.innerHTML = `<h5>Movies</h5>`;
  questionNum.innerHTML = `<h5>Question 20</h5>`;
  gameText.innerHTML = `<h3>${movQuesThree}</h3>`;
  defaultSetting();

  //Buttons
  buttonContent(
    movQuesThreeAnswerA,
    movQuesThreeAnswerB,
    movQuesThreeAnswerC,
    movQuesThreeAnswerD
  );

  addListeners(
    "click",
    movQuesThreeButtonA,
    movQuesThreeButtonB,
    movQuesThreeButtonC,
    movQuesThreeButtonD
  );
}

function movQuesThreeButtonA() {
  if (movieQuestions[movieArr[2]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${movQuesThreeCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionFour);
  } else {
    gameText.innerHTML = `<h3>${movQuesThreeWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionFour);
  }
}

function movQuesThreeButtonB() {
  if (movieQuestions[movieArr[2]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${movQuesThreeCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionFour);
  } else {
    gameText.innerHTML = `<h3>${movQuesThreeWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionFour);
  }
}

function movQuesThreeButtonC() {
  if (movieQuestions[movieArr[2]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${movQuesThreeCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionFour);
  } else {
    gameText.innerHTML = `<h3>${movQuesThreeWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionFour);
  }
}

function movQuesThreeButtonD() {
  if (movieQuestions[movieArr[2]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${movQuesThreeCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionFour);
  } else {
    gameText.innerHTML = `<h3>${movQuesThreeWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionFour);
  }
}

function movieQuestionFour() {
  removeListeners(
    "click",
    movQuesThreeButtonA,
    movQuesThreeButtonB,
    movQuesThreeButtonC,
    movQuesThreeButtonD,
    movieQuestionFour
  );

  category.innerHTML = `<h5>Movies</h5>`;
  questionNum.innerHTML = `<h5>Question 21</h5>`;
  gameText.innerHTML = `<h3>${movQuesFour}</h3>`;
  defaultSetting();

  //Buttons
  buttonContent(
    movQuesFourAnswerA,
    movQuesFourAnswerB,
    movQuesFourAnswerC,
    movQuesFourAnswerD
  );

  addListeners(
    "click",
    movQuesFourButtonA,
    movQuesFourButtonB,
    movQuesFourButtonC,
    movQuesFourButtonD
  );
}

function movQuesFourButtonA() {
  if (movieQuestions[movieArr[3]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${movQuesFourCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionFive);
  } else {
    gameText.innerHTML = `<h3>${movQuesFourWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionFive);
  }
}

function movQuesFourButtonB() {
  if (movieQuestions[movieArr[3]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${movQuesFourCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionFive);
  } else {
    gameText.innerHTML = `<h3>${movQuesFourWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionFive);
  }
}

function movQuesFourButtonC() {
  if (movieQuestions[movieArr[3]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${movQuesFourCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionFive);
  } else {
    gameText.innerHTML = `<h3>${movQuesFourWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionFive);
  }
}

function movQuesFourButtonD() {
  if (movieQuestions[movieArr[3]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${movQuesFourCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionFive);
  } else {
    gameText.innerHTML = `<h3>${movQuesFourWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionFive);
  }
}

function movieQuestionFive() {
  removeListeners(
    "click",
    movQuesFourButtonA,
    movQuesFourButtonB,
    movQuesFourButtonC,
    movQuesFourButtonD,
    movieQuestionFive
  );

  category.innerHTML = `<h5>Movies</h5>`;
  questionNum.innerHTML = `<h5>Question 22</h5>`;
  gameText.innerHTML = `<h3>${movQuesFive}</h3>`;
  defaultSetting();

  //Buttons
  buttonContent(
    movQuesFiveAnswerA,
    movQuesFiveAnswerB,
    movQuesFiveAnswerC,
    movQuesFiveAnswerD
  );

  addListeners(
    "click",
    movQuesFiveButtonA,
    movQuesFiveButtonB,
    movQuesFiveButtonC,
    movQuesFiveButtonD
  );
}

function movQuesFiveButtonA() {
  if (movieQuestions[movieArr[4]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${movQuesFiveCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionSix);
  } else {
    gameText.innerHTML = `<h3>${movQuesFiveWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionSix);
  }
}

function movQuesFiveButtonB() {
  if (movieQuestions[movieArr[4]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${movQuesFiveCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionSix);
  } else {
    gameText.innerHTML = `<h3>${movQuesFiveWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionSix);
  }
}

function movQuesFiveButtonC() {
  if (movieQuestions[movieArr[4]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${movQuesFiveCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionSix);
  } else {
    gameText.innerHTML = `<h3>${movQuesFiveWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionSix);
  }
}

function movQuesFiveButtonD() {
  if (movieQuestions[movieArr[4]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${movQuesFiveCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionSix);
  } else {
    gameText.innerHTML = `<h3>${movQuesFiveWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", movieQuestionSix);
  }
}

function movieQuestionSix() {
  removeListeners(
    "click",
    movQuesFiveButtonA,
    movQuesFiveButtonB,
    movQuesFiveButtonC,
    movQuesFiveButtonD,
    movieQuestionSix
  );

  category.innerHTML = `<h5>Movies</h5>`;
  questionNum.innerHTML = `<h5>Question 24</h5>`;
  gameText.innerHTML = `<h3>${movQuesSix}</h3>`;
  defaultSetting();

  //Buttons
  buttonContent(
    movQuesSixAnswerA,
    movQuesSixAnswerB,
    movQuesSixAnswerC,
    movQuesSixAnswerD
  );

  addListeners(
    "click",
    movQuesSixButtonA,
    movQuesSixButtonB,
    movQuesSixButtonC,
    movQuesSixButtonD
  );
}

function movQuesSixButtonA() {
  if (movieQuestions[movieArr[5]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${movQuesSixCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionOne);
  } else {
    gameText.innerHTML = `<h3>${movQuesSixWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionOne);
  }
}

function movQuesSixButtonB() {
  if (movieQuestions[movieArr[5]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${movQuesSixCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionOne);
  } else {
    gameText.innerHTML = `<h3>${movQuesSixWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionOne);
  }
}

function movQuesSixButtonC() {
  if (movieQuestions[movieArr[5]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${movQuesSixCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionOne);
  } else {
    gameText.innerHTML = `<h3>${movQuesSixWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionOne);
  }
}

function movQuesSixButtonD() {
  if (movieQuestions[movieArr[5]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${movQuesSixCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionOne);
  } else {
    gameText.innerHTML = `<h3>${movQuesSixWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionOne);
  }
}

// GENERAL KNOWLEDGE QUESTION ONE VARIABLES

let genQuesOne = generalQuestions[generalArr[0]].Question;
let genQuesOneAnswerA = generalQuestions[generalArr[0]].OptionA;
let genQuesOneAnswerB = generalQuestions[generalArr[0]].OptionB;
let genQuesOneAnswerC = generalQuestions[generalArr[0]].OptionC;
let genQuesOneAnswerD = generalQuestions[generalArr[0]].OptionD;
let genQuesOneWrongAnswer = generalQuestions[generalArr[0]].WrongAnswerText;
let genQuesOneCorrectAnswer = generalQuestions[generalArr[0]].CorrectAnswerText;

// GENERAL KNOWLEDGE QUESTION TWO VARIABLES

let genQuesTwo = generalQuestions[generalArr[1]].Question;
let genQuesTwoAnswerA = generalQuestions[generalArr[1]].OptionA;
let genQuesTwoAnswerB = generalQuestions[generalArr[1]].OptionB;
let genQuesTwoAnswerC = generalQuestions[generalArr[1]].OptionC;
let genQuesTwoAnswerD = generalQuestions[generalArr[1]].OptionD;
let genQuesTwoWrongAnswer = generalQuestions[generalArr[1]].WrongAnswerText;
let genQuesTwoCorrectAnswer = generalQuestions[generalArr[1]].CorrectAnswerText;

// GENERAL KNOWLEDGE QUESTION THREE VARIABLES

let genQuesThree = generalQuestions[generalArr[2]].Question;
let genQuesThreeAnswerA = generalQuestions[generalArr[2]].OptionA;
let genQuesThreeAnswerB = generalQuestions[generalArr[2]].OptionB;
let genQuesThreeAnswerC = generalQuestions[generalArr[2]].OptionC;
let genQuesThreeAnswerD = generalQuestions[generalArr[2]].OptionD;
let genQuesThreeWrongAnswer = generalQuestions[generalArr[2]].WrongAnswerText;
let genQuesThreeCorrectAnswer =
  generalQuestions[generalArr[2]].CorrectAnswerText;

// GENERAL KNOWLEDGE QUESTION FOUR VARIABLES

let genQuesFour = generalQuestions[generalArr[3]].Question;
let genQuesFourAnswerA = generalQuestions[generalArr[3]].OptionA;
let genQuesFourAnswerB = generalQuestions[generalArr[3]].OptionB;
let genQuesFourAnswerC = generalQuestions[generalArr[3]].OptionC;
let genQuesFourAnswerD = generalQuestions[generalArr[3]].OptionD;
let genQuesFourWrongAnswer = generalQuestions[generalArr[3]].WrongAnswerText;
let genQuesFourCorrectAnswer =
  generalQuestions[generalArr[3]].CorrectAnswerText;

// GENERAL KNOWLEDGE QUESTION FIVE VARIABLES

let genQuesFive = generalQuestions[generalArr[4]].Question;
let genQuesFiveAnswerA = generalQuestions[generalArr[4]].OptionA;
let genQuesFiveAnswerB = generalQuestions[generalArr[4]].OptionB;
let genQuesFiveAnswerC = generalQuestions[generalArr[4]].OptionC;
let genQuesFiveAnswerD = generalQuestions[generalArr[4]].OptionD;
let genQuesFiveWrongAnswer = generalQuestions[generalArr[4]].WrongAnswerText;
let genQuesFiveCorrectAnswer =
  generalQuestions[generalArr[4]].CorrectAnswerText;

// GENERAL KNOWLEDGE QUESTION SIX VARIABLES

let genQuesSix = generalQuestions[generalArr[5]].Question;
let genQuesSixAnswerA = generalQuestions[generalArr[5]].OptionA;
let genQuesSixAnswerB = generalQuestions[generalArr[5]].OptionB;
let genQuesSixAnswerC = generalQuestions[generalArr[5]].OptionC;
let genQuesSixAnswerD = generalQuestions[generalArr[5]].OptionD;
let genQuesSixWrongAnswer = generalQuestions[generalArr[5]].WrongAnswerText;
let genQuesSixCorrectAnswer = generalQuestions[generalArr[5]].CorrectAnswerText;

function generalQuestionOne() {
  removeListeners(
    "click",
    movQuesSixButtonA,
    movQuesSixButtonB,
    movQuesSixButtonC,
    movQuesSixButtonD,
    generalQuestionOne
  );

  category.innerHTML = `<h5>General Knowledge</h5>`;
  questionNum.innerHTML = `<h5>Question 25</h5>`;
  gameText.innerHTML = `<h3>${genQuesOne}</h3>`;
  alert("The Final Round! General Knowledge. Ready?!");
  defaultSetting();

  //Buttons
  buttonContent(
    genQuesOneAnswerA,
    genQuesOneAnswerB,
    genQuesOneAnswerC,
    genQuesOneAnswerD
  );

  addListeners(
    "click",
    genQuesOneButtonA,
    genQuesOneButtonB,
    genQuesOneButtonC,
    genQuesOneButtonD
  );
}

function genQuesOneButtonA() {
  if (generalQuestions[generalArr[0]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${genQuesOneCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionTwo);
  } else {
    gameText.innerHTML = `<h3>${genQuesOneWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionTwo);
  }
}

function genQuesOneButtonB() {
  if (generalQuestions[generalArr[0]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${genQuesOneCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionTwo);
  } else {
    gameText.innerHTML = `<h3>${genQuesOneWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionTwo);
  }
}

function genQuesOneButtonC() {
  if (generalQuestions[generalArr[0]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${genQuesOneCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionTwo);
  } else {
    gameText.innerHTML = `<h3>${genQuesOneWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionTwo);
  }
}

function genQuesOneButtonD() {
  if (generalQuestions[generalArr[0]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${genQuesOneCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionTwo);
  } else {
    gameText.innerHTML = `<h3>${genQuesOneWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionTwo);
  }
}

function generalQuestionTwo() {
  removeListeners(
    "click",
    genQuesOneButtonA,
    genQuesOneButtonB,
    genQuesOneButtonC,
    genQuesOneButtonD,
    generalQuestionTwo
  );

  category.innerHTML = `<h5>General Knowledge</h5>`;
  questionNum.innerHTML = `<h5>Question 26</h5>`;
  gameText.innerHTML = `<h3>${genQuesTwo}</h3>`;
  defaultSetting();

  //Buttons
  buttonContent(
    genQuesTwoAnswerA,
    genQuesTwoAnswerB,
    genQuesTwoAnswerC,
    genQuesTwoAnswerD
  );

  addListeners(
    "click",
    genQuesTwoButtonA,
    genQuesTwoButtonB,
    genQuesTwoButtonC,
    genQuesTwoButtonD
  );
}

function genQuesTwoButtonA() {
  if (generalQuestions[generalArr[1]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${genQuesTwoCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionThree);
  } else {
    gameText.innerHTML = `<h3>${genQuesTwoWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionThree);
  }
}

function genQuesTwoButtonB() {
  if (generalQuestions[generalArr[1]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${genQuesTwoCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionThree);
  } else {
    gameText.innerHTML = `<h3>${genQuesTwoWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionThree);
  }
}

function genQuesTwoButtonC() {
  if (generalQuestions[generalArr[1]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${genQuesTwoCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionThree);
  } else {
    gameText.innerHTML = `<h3>${genQuesTwoWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionThree);
  }
}

function genQuesTwoButtonD() {
  if (generalQuestions[generalArr[1]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${genQuesTwoCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionThree);
  } else {
    gameText.innerHTML = `<h3>${genQuesTwoWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionThree);
  }
}

function generalQuestionThree() {
  removeListeners(
    "click",
    genQuesTwoButtonA,
    genQuesTwoButtonB,
    genQuesTwoButtonC,
    genQuesTwoButtonD,
    generalQuestionThree
  );

  category.innerHTML = `<h5>General Knowledge</h5>`;
  questionNum.innerHTML = `<h5>Question 27</h5>`;
  gameText.innerHTML = `<h3>${genQuesThree}</h3>`;
  defaultSetting();

  //Buttons
  buttonContent(
    genQuesThreeAnswerA,
    genQuesThreeAnswerB,
    genQuesThreeAnswerC,
    genQuesThreeAnswerD
  );

  addListeners(
    "click",
    genQuesThreeButtonA,
    genQuesThreeButtonB,
    genQuesThreeButtonC,
    genQuesThreeButtonD
  );
}

function genQuesThreeButtonA() {
  if (generalQuestions[generalArr[2]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${genQuesThreeCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionFour);
  } else {
    gameText.innerHTML = `<h3>${genQuesThreeWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionFour);
  }
}

function genQuesThreeButtonB() {
  if (generalQuestions[generalArr[2]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${genQuesThreeCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionFour);
  } else {
    gameText.innerHTML = `<h3>${genQuesThreeWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionFour);
  }
}

function genQuesThreeButtonC() {
  if (generalQuestions[generalArr[2]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${genQuesThreeCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionFour);
  } else {
    gameText.innerHTML = `<h3>${genQuesThreeWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionFour);
  }
}

function genQuesThreeButtonD() {
  if (generalQuestions[generalArr[2]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${genQuesThreeCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionFour);
  } else {
    gameText.innerHTML = `<h3>${genQuesThreeWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionFour);
  }
}

function generalQuestionFour() {
  removeListeners(
    "click",
    genQuesThreeButtonA,
    genQuesThreeButtonB,
    genQuesThreeButtonC,
    genQuesThreeButtonD,
    generalQuestionFour
  );

  category.innerHTML = `<h5>General Knowledge</h5>`;
  questionNum.innerHTML = `<h5>Question 28</h5>`;
  gameText.innerHTML = `<h3>${genQuesFour}</h3>`;
  defaultSetting();

  //Buttons
  buttonContent(
    genQuesFourAnswerA,
    genQuesFourAnswerB,
    genQuesFourAnswerC,
    genQuesFourAnswerD
  );

  addListeners(
    "click",
    genQuesFourButtonA,
    genQuesFourButtonB,
    genQuesFourButtonC,
    genQuesFourButtonD
  );
}

function genQuesFourButtonA() {
  if (generalQuestions[generalArr[3]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${genQuesFourCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionFive);
  } else {
    gameText.innerHTML = `<h3>${genQuesFourWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionFive);
  }
}

function genQuesFourButtonB() {
  if (generalQuestions[generalArr[3]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${genQuesFourCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionFive);
  } else {
    gameText.innerHTML = `<h3>${genQuesFourWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionFive);
  }
}

function genQuesFourButtonC() {
  if (generalQuestions[generalArr[3]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${genQuesFourCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionFive);
  } else {
    gameText.innerHTML = `<h3>${genQuesFourWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionFive);
  }
}

function genQuesFourButtonD() {
  if (generalQuestions[generalArr[3]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${genQuesFourCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionFive);
  } else {
    gameText.innerHTML = `<h3>${genQuesFourWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionFive);
  }
}

function generalQuestionFive() {
  removeListeners(
    "click",
    genQuesFourButtonA,
    genQuesFourButtonB,
    genQuesFourButtonC,
    genQuesFourButtonD,
    generalQuestionFive
  );

  category.innerHTML = `<h5>General Knowledge</h5>`;
  questionNum.innerHTML = `<h5>Question 29</h5>`;
  gameText.innerHTML = `<h3>${genQuesFive}</h3>`;
  defaultSetting();

  //Buttons
  buttonContent(
    genQuesFiveAnswerA,
    genQuesFiveAnswerB,
    genQuesFiveAnswerC,
    genQuesFiveAnswerD
  );

  addListeners(
    "click",
    genQuesFiveButtonA,
    genQuesFiveButtonB,
    genQuesFiveButtonC,
    genQuesFiveButtonD
  );
}

function genQuesFiveButtonA() {
  if (generalQuestions[generalArr[4]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${genQuesFiveCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionSix);
  } else {
    gameText.innerHTML = `<h3>${genQuesFiveWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionSix);
  }
}

function genQuesFiveButtonB() {
  if (generalQuestions[generalArr[4]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${genQuesFiveCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionSix);
  } else {
    gameText.innerHTML = `<h3>${genQuesFiveWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionSix);
  }
}

function genQuesFiveButtonC() {
  if (generalQuestions[generalArr[4]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${genQuesFiveCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionSix);
  } else {
    gameText.innerHTML = `<h3>${genQuesFiveWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionSix);
  }
}

function genQuesFiveButtonD() {
  if (generalQuestions[generalArr[4]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${genQuesFiveCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionSix);
  } else {
    gameText.innerHTML = `<h3>${genQuesFiveWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", generalQuestionSix);
  }
}

function generalQuestionSix() {
  removeListeners(
    "click",
    genQuesFiveButtonA,
    genQuesFiveButtonB,
    genQuesFiveButtonC,
    genQuesFiveButtonD,
    generalQuestionSix
  );

  category.innerHTML = `<h5>General Knowledge</h5>`;
  questionNum.innerHTML = `<h5>Question 29</h5>`;
  gameText.innerHTML = `<h3>${genQuesSix}</h3>`;
  defaultSetting();

  //Buttons
  buttonContent(
    genQuesSixAnswerA,
    genQuesSixAnswerB,
    genQuesSixAnswerC,
    genQuesSixAnswerD
  );

  addListeners(
    "click",
    genQuesSixButtonA,
    genQuesSixButtonB,
    genQuesSixButtonC,
    genQuesSixButtonD
  );
}

function genQuesSixButtonA() {
  if (generalQuestions[generalArr[5]].CorrectAnswer === "A") {
    gameText.innerHTML = `<h3>${genQuesSixCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", endGame);
  } else {
    gameText.innerHTML = `<h3>${genQuesSixWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", endGame);
  }
}

function genQuesSixButtonB() {
  if (generalQuestions[generalArr[5]].CorrectAnswer === "B") {
    gameText.innerHTML = `<h3>${genQuesSixCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", endGame);
  } else {
    gameText.innerHTML = `<h3>${genQuesSixWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", endGame);
  }
}

function genQuesSixButtonC() {
  if (generalQuestions[generalArr[5]].CorrectAnswer === "C") {
    gameText.innerHTML = `<h3>${genQuesSixCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", endGame);
  } else {
    gameText.innerHTML = `<h3>${genQuesSixWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", endGame);
  }
}

function genQuesSixButtonD() {
  if (generalQuestions[generalArr[5]].CorrectAnswer === "D") {
    gameText.innerHTML = `<h3>${genQuesSixCorrectAnswer}</h3>`;
    correctAnswerFunc();
    nextBtn.addEventListener("click", endGame);
  } else {
    gameText.innerHTML = `<h3>${genQuesSixWrongAnswer}</h3>`;
    wrongAnswerFunc();
    nextBtn.addEventListener("click", endGame);
  }
}

startBtn.addEventListener('click', geographyQuestionOne);
