const geographyQuestions = [
  {
    QuestionNumber: 1,
    Category: "Geography",
    Question: "What is the capital city of Peru?",
    OptionA: "La Paz",
    OptionB: "Bogota",
    OptionC: "Lima",
    OptionD: "Cancun",
    CorrectAnswer: "C",
    CorrectAnswerText: "Correct! The Peruvian capital is Lima",
    WrongAnswerText: "Wrong! The Peruvian capital is Lima"
  },
  {
    QuestionNumber: 2,
    Category: "Geography",
    Question:
      "In which Middle Eastern country would you find the ancient ruins of Petra?",
    OptionA: "Iraq",
    OptionB: "Iran",
    OptionC: "Lebanon",
    OptionD: "Jordan",
    CorrectAnswer: "D",
    CorrectAnswerText:
      "Correct! Petra is a Wonder of the World and can be found in Jordan",
    WrongAnswerText:
      "Wrong! Petra is a Wonder of the World and can be found in Jordan"
  },
  {
    QuestionNumber: 3,
    Category: "Geography",
    Question: "What is the currency of Sweden?",
    OptionA: "Krona",
    OptionB: "Euro",
    OptionC: "Ruble",
    OptionD: "Yen",
    CorrectAnswer: "A",
    CorrectAnswerText:
      "Correct! The Swedish Krona is the official currency of Sweden",
    WrongAnswerText:
      "Wrong! The Swedish Krona is the official currency of Sweden"
  },
  {
    QuestionNumber: 4,
    Category: "Geography",
    Question: "Mount Vesuvius overlooks which present-day Italian city?",
    OptionA: "Rome",
    OptionB: "Naples",
    OptionC: "Venice",
    OptionD: "Milan",
    CorrectAnswer: "B",
    CorrectAnswerText:
      "Correct! Mount Vesuvius is an active volcano that overlooks Naples",
    WrongAnswerText:
      "Wrong! Mount Vesuvius is an active volcano that overlooks Naples"
  },
  {
    QuestionNumber: 5,
    Category: "Geography",
    Question:
      "Constantinople and Byzantium are former names of which major city?",
    OptionA: "Athens",
    OptionB: "Istanbul",
    OptionC: "Tehran",
    OptionD: "Zagreb",
    CorrectAnswer: "B",
    CorrectAnswerText:
      "Correct! The Byzantine Empires capital city was Constantinople, which today is Istanbul",
    WrongAnswerText:
      "Wrong! The Byzantine Empires capital city was Constantinople, which today is Istanbul"
  },
  {
    QuestionNumber: 6,
    Category: "Geography",
    Question: "What is the largest desert in the world?",
    OptionA: "Sahara",
    OptionB: "Gobi",
    OptionC: "Atacama",
    OptionD: "Antarctica",
    CorrectAnswer: "D",
    CorrectAnswerText:
      "Correct! At 5.5 million square miles, Antarctica is by far the worlds largest desert",
    WrongAnswerText:
      "Wrong! At 5.5 million square miles, Antarctica is by far the worlds largest desert"
  },
  {
    QuestionNumber: 7,
    Category: "Geography",
    Question:
      "What is the name of the microstate located between Spain and France?",
    OptionA: "Andorra",
    OptionB: "Monaco",
    OptionC: "Montenegro",
    OptionD: "Almaty",
    CorrectAnswer: "A",
    CorrectAnswerText: "Correct! Its Andorra",
    WrongAnswerText: "Wrong! Its Andorra"
  },
  {
    QuestionNumber: 8,
    Category: "Geography",
    Question: "To the nearest billion, how large is the worlds population?",
    OptionA: "77 Billion",
    OptionB: "50 Billion",
    OptionC: "22 Billion",
    OptionD: "8 Billion",
    CorrectAnswer: "D",
    CorrectAnswerText:
      "Correct! The more accurate figure is roughly 7.8 billion",
    WrongAnswerText: "Wrong! The more accurate figure is roughly 7.8 billion"
  },
  {
    QuestionNumber: 9,
    Category: "Geography",
    Question: "In which UK city would you find the river Clyde?",
    OptionA: "Manchester",
    OptionB: "Belfast",
    OptionC: "Glasgow",
    OptionD: "Newcastle",
    CorrectAnswer: "C",
    CorrectAnswerText:
      "Correct! The river Clyde runs through the major city of Glasgow",
    WrongAnswerText:
      "Wrong! The river Clyde runs through the major city of Glasgow"
  },
  {
    QuestionNumber: 10,
    Category: "Geography",
    Question: "How many states are there in Australia?",
    OptionA: 6,
    OptionB: 8,
    OptionC: 10,
    OptionD: 12,
    CorrectAnswer: "A",
    CorrectAnswerText:
      "Correct! Six – New South Wales, Victoria, Queensland, Western Australia, Tasmania, South Australia",
    WrongAnswerText:
      "Wrong! Six – New South Wales, Victoria, Queensland, Western Australia, Tasmania, South Australia"
  }
];

const scienceQuestions = [
  {
    QuestionNumber: 1,
    Category: "Science",
    Question: "How many bones are in the human body?",
    OptionA: 188,
    OptionB: 209,
    OptionC: 272,
    OptionD: 301,
    CorrectAnswer: "B",
    CorrectAnswerText: "Correct! There are 209 bones in the human body",
    WrongAnswerText: "Wrong! There are 209 bones in the human body"
  },
  {
    QuestionNumber: 2,
    Category: "Science",
    Question:
      "The concept of gravity was discovered by which famous physicist?",
    OptionA: "Newton",
    OptionB: "Einstein",
    OptionC: "Curie",
    OptionD: "Galilei",
    CorrectAnswer: "A",
    CorrectAnswerText:
      "Correct! Isaac Newton formulated gravitational theory in 1665",
    WrongAnswerText:
      "Wrong! Isaac Newton formulated gravitational theory in 1665"
  },
  {
    QuestionNumber: 3,
    Category: "Science",
    Question:
      "Roughly how long does it take for the suns light to reach Earth?",
    OptionA: "8 seconds",
    OptionB: "8 minutes",
    OptionC: "8 hours",
    OptionD: "8 days",
    CorrectAnswer: "B",
    CorrectAnswerText: "Correct! It takes roughly 8 minutes",
    WrongAnswerText: "Wrong! It takes roughly 8 minutes"
  },
  {
    QuestionNumber: 4,
    Category: "Science",
    Question: "What is the study of mushrooms called?",
    OptionA: "Botany",
    OptionB: "Biology",
    OptionC: "Ornithology",
    OptionD: "Mycology",
    CorrectAnswer: "D",
    CorrectAnswerText: "Correct! Mycology the scientific study of fungi",
    WrongAnswerText: "Wrong! Mycology the scientific study of fungi"
  },
  {
    QuestionNumber: 5,
    Category: "Science",
    Question: "What is the hardest natural substance on Earth?",
    OptionA: "Diamond",
    OptionB: "Iron",
    OptionC: "Gold",
    OptionD: "Silver",
    CorrectAnswer: "A",
    CorrectAnswerText:
      "Correct! Diamond is the hardest natural substance on Earth",
    WrongAnswerText: "Wrong! Diamond is the hardest natural substance on Earth"
  },
  {
    QuestionNumber: 6,
    Category: "Science",
    Question: "Which is the main gas that makes up the Earths atmosphere?",
    OptionA: "Oxygen",
    OptionB: "Butane",
    OptionC: "Nitrogen",
    OptionD: "Helium",
    CorrectAnswer: "C",
    CorrectAnswerText:
      "Correct! Earths atmosphere is made up of approximately 78% nitrogen and 21% oxygen",
    WrongAnswerText:
      "Wrong! Earths atmosphere is made up of approximately 78% nitrogen and 21% oxygen"
  },
  {
    QuestionNumber: 7,
    Category: "Science",
    Question: "What modern-day country was Marie Curie born in?",
    OptionA: "England",
    OptionB: "Poland",
    OptionC: "Germany",
    OptionD: "France",
    CorrectAnswer: "B",
    CorrectAnswerText:
      "Correct! Marie Curie was born in Warsaw, Poland in 1867",
    WrongAnswerText: "Wrong! Marie Curie was born in Warsaw, Poland in 1867"
  },
  {
    QuestionNumber: 8,
    Category: "Science",
    Question: "What is the biggest planet in our solar system?",
    OptionA: "Mars",
    OptionB: "Jupiter",
    OptionC: "Saturn",
    OptionD: "Mercury",
    CorrectAnswer: "B",
    CorrectAnswerText:
      "Correct! Jupiter is the largest planet at 61.42 billion km²",
    WrongAnswerText: "Wrong! Jupiter is the largest planet at 61.42 billion km²"
  },
  {
    QuestionNumber: 9,
    Category: "Science",
    Question: "At what temperature are Celsius and Fahrenheit equal?",
    OptionA: 0,
    OptionB: -10,
    OptionC: -25,
    OptionD: -40,
    CorrectAnswer: "D",
    CorrectAnswerText: "Correct! Celsius and Fahrenheit are equal at -40",
    WrongAnswerText: "Wrong! Celsius and Fahrenheit are equal at -40"
  },
  {
    QuestionNumber: 10,
    Category: "Science",
    Question: "How many teeth does an adult human have?",
    OptionA: 32,
    OptionB: 38,
    OptionC: 40,
    OptionD: 42,
    CorrectAnswer: "A",
    CorrectAnswerText: "Correct! The average adult human has 32 teeth",
    WrongAnswerText: "Wrong! The average adult human has 32 teeth"
  }
];

//GAME VARIABLES

const startBtn = document.getElementById("start-btn");
const resetBtn = document.getElementById("reset-btn");
const box1 = document.getElementById("box1");
const nextBtn = document.getElementById("next-btn");
const gameText = document.getElementById("game-text");
const optionAbutton = document.getElementById("optionA");
const optionBbutton = document.getElementById("optionB");
const optionCbutton = document.getElementById("optionC");
const optionDbutton = document.getElementById("optionD");
const scoreBox = document.getElementById("score-box");
const category = document.getElementById("category");
const questionNum = document.getElementById("question-number");
let score = 0;

// SHUFFLED ARRAY FUNCTIONS

//Geography Array
function shuffleGeographyArray(array) {
  array.sort(() => Math.random() - 0.5);
}
var geographyArr = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
shuffleGeographyArray(geographyArr);

//Science Array
function shuffleScienceArray(array) {
  array.sort(() => Math.random() - 0.5);
}
var scienceArr = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
shuffleScienceArray(scienceArr);

//History Array
function shuffleHistoryArray(array) {
  array.sort(() => Math.random() - 0.5);
}
var historyArr = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
shuffleHistoryArray(historyArr);

//Movies Array
function shuffleMovieArray(array) {
  array.sort(() => Math.random() - 0.5);
}
var movieArr = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
shuffleMovieArray(movieArr);

//General Knowlege Array
function shuffleGeneralArray(array) {
  array.sort(() => Math.random() - 0.5);
}
var generalArr = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
shuffleGeneralArray(generalArr);

//GEOGRAPHY QUESTION ONE VARIABLES

let geoQuesOne = geographyQuestions[geographyArr[0]].Question;
let geoQuesOneAnswerA = geographyQuestions[geographyArr[0]].OptionA;
let geoQuesOneAnswerB = geographyQuestions[geographyArr[0]].OptionB;
let geoQuesOneAnswerC = geographyQuestions[geographyArr[0]].OptionC;
let geoQuesOneAnswerD = geographyQuestions[geographyArr[0]].OptionD;
let geoQuesOneWrongAnswer = geographyQuestions[geographyArr[0]].WrongAnswerText;
let geoQuesOneCorrectAnswer =
  geographyQuestions[geographyArr[0]].CorrectAnswerText;
